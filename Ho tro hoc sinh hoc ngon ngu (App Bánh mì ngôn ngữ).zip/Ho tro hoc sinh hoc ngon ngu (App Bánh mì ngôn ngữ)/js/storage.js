/**
 * BÁNH MÌ NGÔN NGỮ — Quản lý Lưu trữ LocalStorage & Thuật toán Lặp lại Ngắt quãng
 * Dữ liệu lưu 100% trên máy người dùng, an toàn, không lo mất mạng hay tốn phí.
 */

const STORAGE_KEYS = {
  PROFILE: 'bm_user_profile',
  DIAGNOSTIC: 'bm_user_diagnostic',
  ROADMAP: 'bm_user_roadmap',
  FLASHCARDS: 'bm_user_flashcards',
  STREAK: 'bm_user_streak',
  POMODORO: 'bm_user_pomodoro',
  CHAT: 'bm_user_chat_history'
};

const Storage = {
  // 1. User Profile
  getProfile() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.warn('Lỗi đọc profile:', e);
    }
    return {
      name: 'Lê Văn Trọng',
      language: 'en',
      dailyMinutes: 10,
      theme: 'light',
      voiceGender: 'female',
      voiceRate: 0.95,
      voicePitch: 1.0,
      apiKey: '',
      hasOnboarded: false
    };
  },

  saveProfile(profile) {
    const current = this.getProfile();
    const updated = { ...current, ...profile };
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(updated));
    return updated;
  },

  // 2. Diagnostic & Placement Test
  getDiagnostic() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DIAGNOSTIC);
      if (data) return JSON.parse(data);
    } catch (e) {}
    return {
      completed: false,
      score: 0,
      total: 10,
      pct: 0,
      level: 'starter',
      testedAt: null,
      skills: {}
    };
  },

  saveDiagnostic(results) {
    localStorage.setItem(STORAGE_KEYS.DIAGNOSTIC, JSON.stringify(results));
  },

  // 3. Roadmap / Personalized Lessons (9 micro-lessons)
  getRoadmap(lang = 'en') {
    const key = `${STORAGE_KEYS.ROADMAP}_${lang}`;
    try {
      const data = localStorage.getItem(key);
      if (data) return JSON.parse(data);
    } catch (e) {}

    // Generate initial 9 lessons based on language
    const initialUnits = [
      {
        id: 'u1',
        title: 'Chặng 1 · Nền tảng cốt lõi (5–7 phút)',
        focus: 'Cấu trúc câu & Từ vựng sinh hoạt',
        lessons: [
          { id: 'u1_l1', title: 'Bài 1: Làm quen & Giới thiệu bản thân', done: false, score: 0, duration: 5 },
          { id: 'u1_l2', title: 'Bài 2: Đồ vật trong lớp & Khuôn viên trường', done: false, score: 0, duration: 7 },
          { id: 'u1_l3', title: 'Bài 3: Trật tự câu đơn giản và đại từ', done: false, score: 0, duration: 6 }
        ]
      },
      {
        id: 'u2',
        title: 'Chặng 2 · Phản xạ giao tiếp trường lớp (7–10 phút)',
        focus: 'Thói quen & Giao tiếp tự tin',
        lessons: [
          { id: 'u2_l1', title: 'Bài 4: Hỏi đường & Đi lại quanh campus', done: false, score: 0, duration: 8 },
          { id: 'u2_l2', title: 'Bài 5: Gọi món bánh mì & đồ uống sau giờ học', done: false, score: 0, duration: 7 },
          { id: 'u2_l3', title: 'Bài 6: Dạy lại cho Bắp — Phương pháp Feynman', done: false, score: 0, duration: 10 }
        ]
      },
      {
        id: 'u3',
        title: 'Chặng 3 · Bứt phá chuẩn đầu ra (10 phút)',
        focus: 'Kể chuyện & Tự tin hội thoại',
        lessons: [
          { id: 'u3_l1', title: 'Bài 7: Kể về buổi học hôm nay và bài tập', done: false, score: 0, duration: 9 },
          { id: 'u3_l2', title: 'Bài 8: Kế hoạch cuối tuần & Ước mơ du học', done: false, score: 0, duration: 10 },
          { id: 'u3_l3', title: 'Bài 9: Tổng kết lộ trình & Thử thách cùng AI', done: false, score: 0, duration: 10 }
        ]
      }
    ];

    localStorage.setItem(key, JSON.stringify(initialUnits));
    return initialUnits;
  },

  markLessonDone(lang, lessonId, score = 100) {
    const units = this.getRoadmap(lang);
    for (const unit of units) {
      for (const lesson of unit.lessons) {
        if (lesson.id === lessonId) {
          lesson.done = true;
          lesson.score = score;
          lesson.completedAt = new Date().toISOString();
        }
      }
    }
    localStorage.setItem(`${STORAGE_KEYS.ROADMAP}_${lang}`, JSON.stringify(units));
    this.recordDailyActivity();
    return units;
  },

  // 4. Spaced Repetition Flashcards (Sổ ôn tập ngắt quãng)
  getFlashcards(lang = 'en') {
    const key = `${STORAGE_KEYS.FLASHCARDS}_${lang}`;
    try {
      const data = localStorage.getItem(key);
      if (data) return JSON.parse(data);
    } catch (e) {}

    // Seed default cards from VOCABULARY_BANKS
    const defaults = (VOCABULARY_BANKS[lang] || []).map((item, idx) => ({
      id: item.id || `card_${idx}`,
      word: item.word,
      ipa: item.ipa || item.pinyin || item.romaji || item.romaja || '',
      vi: item.vi,
      topic: item.topic || 'Hằng ngày',
      example: item.example || '',
      exVi: item.exVi || '',
      box: 1,                  // Leitner box 1-5
      intervalDays: 1,
      nextReview: Date.now(),   // Ready to review immediately
      reviewCount: 0,
      rememberCount: 0
    }));

    localStorage.setItem(key, JSON.stringify(defaults));
    return defaults;
  },

  saveFlashcards(lang, cards) {
    localStorage.setItem(`${STORAGE_KEYS.FLASHCARDS}_${lang}`, JSON.stringify(cards));
  },

  getDueCards(lang = 'en') {
    const now = Date.now();
    const cards = this.getFlashcards(lang);
    // Cards whose nextReview <= now, or not reviewed yet
    return cards.filter(c => !c.nextReview || c.nextReview <= now);
  },

  // Update card review with Spaced Repetition logic
  updateCardReview(lang, cardId, remembered) {
    const cards = this.getFlashcards(lang);
    const card = cards.find(c => c.id === cardId);
    if (!card) return;

    card.reviewCount = (card.reviewCount || 0) + 1;
    const oneDayMs = 24 * 60 * 60 * 1000;

    if (remembered) {
      card.rememberCount = (card.rememberCount || 0) + 1;
      card.box = Math.min(5, (card.box || 1) + 1);

      // Spaced intervals: Box 1: 1 day, Box 2: 3 days, Box 3: 7 days, Box 4: 14 days, Box 5: 30 days
      const intervals = [1, 1, 3, 7, 14, 30];
      card.intervalDays = intervals[card.box] || 30;
      card.nextReview = Date.now() + (card.intervalDays * oneDayMs);
    } else {
      // If forgotten, drop back to Box 1 for immediate reinforcement
      card.box = 1;
      card.intervalDays = 1;
      card.nextReview = Date.now(); // review again today
    }

    this.saveFlashcards(lang, cards);
    this.recordDailyActivity();
    return card;
  },

  addCustomCard(lang, newCard) {
    const cards = this.getFlashcards(lang);
    const card = {
      id: 'custom_' + Date.now(),
      word: newCard.word.trim(),
      ipa: newCard.ipa ? newCard.ipa.trim() : '',
      vi: newCard.vi.trim(),
      topic: newCard.topic ? newCard.topic.trim() : 'Ghi chú trên lớp',
      example: newCard.example ? newCard.example.trim() : '',
      exVi: newCard.exVi ? newCard.exVi.trim() : '',
      box: 1,
      intervalDays: 1,
      nextReview: Date.now(),
      reviewCount: 0,
      rememberCount: 0
    };
    cards.unshift(card);
    this.saveFlashcards(lang, cards);
    return card;
  },

  deleteCard(lang, cardId) {
    const cards = this.getFlashcards(lang);
    const filtered = cards.filter(c => c.id !== cardId);
    this.saveFlashcards(lang, filtered);
  },

  // 5. Gentle Streak Tracking (No-shame, encouraging!)
  getStreak() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.STREAK);
      if (data) return JSON.parse(data);
    } catch (e) {}

    return {
      count: 1,
      lastActiveDate: new Date().toISOString().split('T')[0],
      history: [new Date().toISOString().split('T')[0]],
      message: 'Chào mừng bạn! Hãy bắt đầu hôm nay thật nhẹ nhàng nhé.'
    };
  },

  recordDailyActivity() {
    const streak = this.getStreak();
    const today = new Date().toISOString().split('T')[0];

    if (streak.lastActiveDate === today) {
      return streak; // already recorded today
    }

    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (streak.lastActiveDate === yesterday) {
      streak.count += 1;
      streak.message = `Tuyệt vời! Bạn đang duy trì chuỗi ${streak.count} ngày đều đặn.`;
    } else {
      // Missed a day — gentle restart, no punishment!
      streak.count = 1;
      streak.message = 'Hôm nay bắt đầu lại thật tươi vui nào, không có gì phải lo lắng!';
    }

    streak.lastActiveDate = today;
    if (!streak.history.includes(today)) {
      streak.history.push(today);
    }

    localStorage.setItem(STORAGE_KEYS.STREAK, JSON.stringify(streak));
    return streak;
  },

  // 6. Pomodoro Statistics
  getPomodoro() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.POMODORO);
      if (data) return JSON.parse(data);
    } catch (e) {}
    return {
      completedSessions: 0,
      totalMinutes: 0
    };
  },

  incrementPomodoro(minutes = 25) {
    const stats = this.getPomodoro();
    stats.completedSessions += 1;
    stats.totalMinutes += minutes;
    localStorage.setItem(STORAGE_KEYS.POMODORO, JSON.stringify(stats));
    this.recordDailyActivity();
    return stats;
  },

  // 7. Reset all app data
  resetAll() {
    localStorage.clear();
  }
};
