/**
 * BÁNH MÌ NGÔN NGỮ — Hệ thống Âm thanh & Luyện nói AI
 * Tích hợp Web Speech API (Text-to-Speech & Speech-to-Text)
 * Hoạt động 100% trên trình duyệt (Chrome, Edge, Safari), không cần cài thêm thư viện ngoài.
 */

const Speech = {
  synth: window.speechSynthesis,
  recognition: null,
  isListening: false,

  // 1. Text to Speech (Đọc mẫu chuẩn bản ngữ)
  speak(text, langCode = 'en', onEnd = null) {
    if (!this.synth) {
      console.warn('Trình duyệt chưa hỗ trợ SpeechSynthesis.');
      return;
    }

    // Cancel current speaking
    this.synth.cancel();

    if (!text) return;

    const profile = Storage.getProfile();
    const utterance = new SpeechSynthesisUtterance(text);

    // Map language code to standard BCP-47
    const langMap = {
      en: 'en-US',
      zh: 'zh-CN',
      ja: 'ja-JP',
      ko: 'ko-KR'
    };
    utterance.lang = langMap[langCode] || 'en-US';

    // Rate & Pitch based on user settings
    utterance.rate = profile.voiceRate || 0.95; // Slightly slower for language learners
    utterance.pitch = profile.voicePitch || 1.0;

    // Pick best matching voice
    const voices = this.synth.getVoices();
    if (voices && voices.length > 0) {
      const targetLang = utterance.lang.toLowerCase();
      const match = voices.find(v => v.lang.toLowerCase().startsWith(targetLang.substring(0, 2)));
      if (match) {
        utterance.voice = match;
      }
    }

    if (onEnd) {
      utterance.onend = onEnd;
      utterance.onerror = onEnd;
    }

    this.synth.speak(utterance);
  },

  stopSpeaking() {
    if (this.synth) {
      this.synth.cancel();
    }
  },

  // 2. Speech to Text (Nhận diện giọng nói sinh viên)
  startListening(langCode = 'en', onResult, onError, onStart, onEnd) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      if (onError) {
        onError('Trình duyệt của bạn chưa hỗ trợ nhận diện giọng nói. Hãy thử dùng Google Chrome hoặc Microsoft Edge nhé!');
      }
      return null;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      const recognition = new SpeechRecognition();
      this.recognition = recognition;
      this.isListening = true;

      const langMap = {
        en: 'en-US',
        zh: 'zh-CN',
        ja: 'ja-JP',
        ko: 'ko-KR'
      };
      recognition.lang = langMap[langCode] || 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      recognition.continuous = false;

      recognition.onstart = () => {
        this.isListening = true;
        if (onStart) onStart();
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (onResult) onResult(transcript);
      };

      recognition.onerror = (event) => {
        this.isListening = false;
        let msg = 'Chưa nghe rõ giọng của bạn. Hãy nói lại gần micro hơn một chút nhé!';
        if (event.error === 'not-allowed') {
          msg = 'Bạn cần cấp quyền truy cập micro cho trình duyệt để luyện nói.';
        } else if (event.error === 'network') {
          msg = 'Cần kết nối mạng để kích hoạt nhận diện giọng nói.';
        }
        if (onError) onError(msg);
      };

      recognition.onend = () => {
        this.isListening = false;
        if (onEnd) onEnd();
      };

      recognition.start();
      return recognition;
    } catch (err) {
      console.error('Lỗi khởi động nhận diện giọng nói:', err);
      if (onError) onError('Không thể kích hoạt micro. Vui lòng kiểm tra lại thiết bị.');
      return null;
    }
  },

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  },

  // 3. Pronunciation Accuracy Scoring & Comparison
  calculateAccuracy(targetText, spokenText) {
    if (!targetText || !spokenText) {
      return { score: 0, words: [], message: 'Chưa nhận được âm thanh' };
    }

    // Clean punctuation and normalize
    const clean = str => str.toLowerCase().replace(/[\.,-\/#!$%\^&\*;:{}=\-_`~()?'"“”]/g, "").trim();
    const targetWords = clean(targetText).split(/\s+/).filter(Boolean);
    const spokenWords = clean(spokenText).split(/\s+/).filter(Boolean);

    if (targetWords.length === 0) return { score: 0, words: [] };

    let matchedCount = 0;
    const evaluatedWords = targetWords.map(tw => {
      const found = spokenWords.includes(tw);
      if (found) matchedCount += 1;
      return {
        word: tw,
        matched: found
      };
    });

    const accuracyScore = Math.round((matchedCount / targetWords.length) * 100);

    let feedback = '';
    let color = '';
    if (accuracyScore >= 80) {
      feedback = 'Xuất sắc! Bạn phát âm rất chuẩn và tự tin!';
      color = '#2E7D32';
    } else if (accuracyScore >= 50) {
      feedback = 'Khá lắm! Bạn đã nói đúng phần lớn từ. Thử luyện lại các từ màu đỏ nhé!';
      color = '#E05F2B';
    } else {
      feedback = 'Không sao cả! Bạn hãy bấm nghe lại câu mẫu rồi thử đọc lại từng từ nhé!';
      color = '#C62828';
    }

    return {
      score: accuracyScore,
      words: evaluatedWords,
      spoken: spokenText,
      feedback: feedback,
      color: color
    };
  }
};

// Pre-load voices when available
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    Speech.synth.getVoices();
  };
}
