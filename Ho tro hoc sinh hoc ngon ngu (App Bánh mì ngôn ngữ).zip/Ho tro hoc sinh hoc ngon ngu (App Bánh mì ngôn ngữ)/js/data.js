/**
 * BÁNH MÌ NGÔN NGỮ - Dữ liệu cốt lõi & Ngân hàng bài học
 * Dựa trên bài tập Tư duy thiết kế & Đổi mới sáng tạo — Nhóm 7 (Quyết Chiến)
 * Persona: Lê Văn Trọng, SV năm nhất MIT University
 */

const LANGUAGES = {
  en: {
    code: 'en',
    label: 'Tiếng Anh',
    native: 'English',
    flag: '🇬🇧',
    speech: 'en-US',
    accentColor: '#9E4E16',
    desc: 'Ngôn ngữ toàn cầu, chuẩn đầu ra đại học và giao tiếp công sở'
  },
  zh: {
    code: 'zh',
    label: 'Tiếng Trung',
    native: '中文 (Tiếng Hoa)',
    flag: '🇨🇳',
    speech: 'zh-CN',
    accentColor: '#D08B3E',
    desc: 'Cơ hội việc làm rộng mở, cấu trúc gần gũi với tiếng Việt'
  },
  ja: {
    code: 'ja',
    label: 'Tiếng Nhật',
    native: '日本語 (Tiếng Nhật)',
    flag: '🇯🇵',
    speech: 'ja-JP',
    accentColor: '#C96A6A',
    desc: 'Văn hóa đặc sắc, cơ hội du học và làm việc tại Nhật Bản'
  },
  ko: {
    code: 'ko',
    label: 'Tiếng Hàn',
    native: '한국어 (Tiếng Hàn)',
    flag: '🇰🇷',
    speech: 'ko-KR',
    accentColor: '#6E6BB0',
    desc: 'Làn sóng văn hóa K-Wave, ngữ pháp chuẩn mực logic'
  }
};

const DAILY_QUOTES = {
  en: [
    {
      quote: "A journey of a thousand miles begins with a single step.",
      vi: "Hành trình vạn dặm bắt đầu từ một bước chân nhỏ.",
      author: "Lao Tzu",
      speak: "A journey of a thousand miles begins with a single step.",
      tip: "Mỗi ngày chỉ cần 5–10 phút, không dồn nén, kiến thức sẽ tự bén rễ."
    },
    {
      quote: "Do not fear mistakes. There are none.",
      vi: "Đừng sợ mắc lỗi. Trong học tập, không có lỗi lầm nào là vô ích.",
      author: "Miles Davis",
      speak: "Do not fear mistakes. There are none.",
      tip: "Sai là cách não bộ bạn đang tự hiệu chỉnh để nói chuẩn hơn."
    },
    {
      quote: "Small daily improvements over time lead to stunning results.",
      vi: "Những tiến bộ nhỏ mỗi ngày theo thời gian sẽ tạo nên kết quả phi thường.",
      author: "Robin Sharma",
      speak: "Small daily improvements over time lead to stunning results.",
      tip: "Đừng áp lực streak như nhiệm vụ, hãy biến nó thành niềm vui nhẹ nhàng."
    }
  ],
  zh: [
    {
      quote: "千里之行，始于足下。",
      pinyin: "Qiān lǐ zhī xíng, shǐ yú zú xià.",
      vi: "Hành trình ngàn dặm bắt đầu từ bước đầu tiên dưới chân.",
      author: "Lão Tử",
      speak: "千里之行，始于足下。",
      tip: "Học chữ Hán mỗi ngày 3 chữ, một năm bạn đã có hơn 1000 từ vựng."
    },
    {
      quote: "熟能生巧。",
      pinyin: "Shú néng shēng qiǎo.",
      vi: "Trăm hay không bằng tay quen.",
      author: "Tục ngữ",
      speak: "熟能生巧。",
      tip: "Nói nhiều lần với bạn AI sẽ giúp khẩu hình lưỡi của bạn dẻo hơn."
    }
  ],
  ja: [
    {
      quote: "七転び八起き。",
      romaji: "Nana korobi ya oki.",
      vi: "Bảy lần ngã, tám lần đứng dậy.",
      author: "Tục ngữ Nhật Bản",
      speak: "七転び八起き。",
      tip: "Quên từ là hiện tượng tự nhiên của não bộ, hãy để Spaced Repetition nhắc bạn."
    },
    {
      quote: "継続は力なり。",
      romaji: "Keizoku wa chikara nari.",
      vi: "Kiên trì chính là sức mạnh lớn nhất.",
      author: "Châm ngôn",
      speak: "継続は力なり。",
      tip: "5 phút mỗi ngày hiệu quả hơn gấp nhiều lần việc học dồn 3 tiếng cuối tuần."
    }
  ],
  ko: [
    {
      quote: "시작이 반이다.",
      romaja: "Sijagi banida.",
      vi: "Khởi đầu là đã hoàn thành được một nửa chặng đường.",
      author: "Tục ngữ Hàn Quốc",
      speak: "시작이 반이다.",
      tip: "Bạn đã dám mở app hôm nay nghĩa là bạn đã tiến bộ hơn ngày hôm qua rồi!"
    },
    {
      quote: "천리 길도 한 걸음부터.",
      romaja: "Cheonli gildo han georeumbuteo.",
      vi: "Đường ngàn dặm cũng bắt đầu từ một bước đi.",
      author: "Tục ngữ",
      speak: "천리 길도 한 걸음부터.",
      tip: "Học phát âm chuẩn trước, ngữ pháp và từ vựng sẽ theo sau rất nhanh."
    }
  ]
};

// 40 Placement Test Questions (10 per language)
const PLACEMENT_QUESTIONS = {
  en: [
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "I ___ a student at MIT University.",
      options: ["am", "is", "are", "be"],
      answer: 0,
      note: 'Với đại từ "I", động từ to be ở hiện tại luôn là "am".'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ nào dưới đây có nghĩa là "con mèo"?',
      options: ["dog", "cat", "bird", "fish"],
      answer: 1,
      note: 'cat = con mèo, dog = con chó, bird = chim, fish = cá.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "She ___ to school by bus every day.",
      options: ["go", "going", "goes", "gone"],
      answer: 2,
      note: 'Chủ ngữ ngôi thứ ba số ít (She) ở thì hiện tại đơn: động từ kết thúc bằng "o" thêm "-es" (goes).'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ trái nghĩa với "hot" (nóng) là gì?',
      options: ["cold", "warm", "big", "new"],
      answer: 0,
      note: 'hot (nóng) trái nghĩa với cold (lạnh).'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "___ you like coffee or tea?",
      options: ["Do", "Does", "Are", "Is"],
      answer: 0,
      note: 'Câu hỏi thì hiện tại đơn với chủ ngữ "you" và động từ thường "like" dùng trợ động từ "Do".'
    },
    {
      skill: 'reading',
      skillLabel: 'Đọc hiểu',
      prompt: 'Đọc: "Hi, I\'m Lan. I\'m 19 and study at university. I want to learn English to travel." — Vì sao Lan muốn học tiếng Anh?',
      options: ["Để đi du lịch", "Để đi làm thêm", "Để đi du học", "Để nấu ăn"],
      answer: 0,
      note: '"to travel" trong câu có nghĩa là để đi du lịch.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "Yesterday I ___ to the university library with my friends.",
      options: ["go", "went", "going", "gone"],
      answer: 1,
      note: '"Yesterday" là dấu hiệu thì quá khứ đơn, quá khứ của "go" là "went".'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: 'Dạng số nhiều bất quy tắc của từ "child" là gì?',
      options: ["childs", "childes", "children", "childrens"],
      answer: 2,
      note: 'Danh từ "child" (1 đứa trẻ) có dạng số nhiều là "children" (những đứa trẻ).'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ nào dưới đây có nghĩa là "thư viện"?',
      options: ["library", "laboratory", "bakery", "gallery"],
      answer: 0,
      note: 'library = thư viện, laboratory = phòng thí nghiệm, bakery = tiệm bánh.'
    },
    {
      skill: 'reading',
      skillLabel: 'Đọc hiểu',
      prompt: 'Đọc: "My morning class starts at 7:30. I usually take the bus because my dorm is far from school." — Bạn ấy thường đến trường bằng gì?',
      options: ["Xe đạp", "Xe buýt", "Đi bộ", "Xe máy"],
      answer: 1,
      note: '"take the bus" nghĩa là bắt xe buýt đi học.'
    }
  ],
  zh: [
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "我 ___ 学生。(Tôi là học sinh)",
      options: ["是", "有", "在", "去"],
      answer: 0,
      note: 'Câu định danh "A là B" trong tiếng Trung dùng 是 (shì).'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: '「谢谢」 (xièxie) có nghĩa là gì?',
      options: ["Xin lỗi", "Cảm ơn", "Xin chào", "Tạm biệt"],
      answer: 1,
      note: '谢谢 = cảm ơn, 不客气 = không có chi.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Số 5 trong tiếng Trung viết là:',
      options: ["五", "三", "四", "十"],
      answer: 0,
      note: '五 (wǔ) = số 5, 三 = 3, 四 = 4, 十 = 10.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "你是 ___ 国人？(Bạn là người nước nào?)",
      options: ["哪", "什么", "谁", "几"],
      answer: 0,
      note: '哪国人 (nǎ guó rén) = người nước nào.'
    },
    {
      skill: 'reading',
      skillLabel: 'Đọc hiểu',
      prompt: 'Đọc: 「我每天早上喝咖啡。」 — Câu này có nghĩa là:',
      options: ["Tôi uống cà phê mỗi sáng", "Tôi uống trà mỗi tối", "Tôi ăn sáng mỗi ngày", "Tôi đi học mỗi sáng"],
      answer: 0,
      note: '每天 = mỗi ngày, 早上 = buổi sáng, 喝咖啡 = uống cà phê.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ 「猫」(māo) chỉ con vật nào?',
      options: ["Con chó", "Con mèo", "Con gà", "Con cá"],
      answer: 1,
      note: '猫 (māo) = con mèo, 狗 (gǒu) = con chó.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "Chọn lượng từ đúng: 一 ___ 书 (Một cuốn sách)",
      options: ["本", "只", "个", "杯"],
      answer: 0,
      note: 'Sách vở dùng lượng từ 本 (běn): 一本书.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Cụm từ 「请问」(qǐngwèn) dùng khi nào?',
      options: ["Khi muốn hỏi một cách lịch sự", "Khi chào tạm biệt", "Khi cảm ơn", "Khi tính tiền"],
      answer: 0,
      note: '请问 = Xin hỏi (lời mở đầu lịch sự trước khi hỏi người khác).'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "他 ___ 去学校。(Ngày mai anh ấy đi học)",
      options: ["明天", "很", "是", "的"],
      answer: 0,
      note: 'Trạng từ thời gian 明天 (míngtiān = ngày mai) đứng trước động từ.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ 「好吃」(hǎochī) nghĩa là gì?',
      options: ["Đẹp mắt", "Ngon miệng", "Nhanh chóng", "Nóng hổi"],
      answer: 1,
      note: '好吃 = ngon (dành cho đồ ăn), 好喝 = ngon (dành cho đồ uống).'
    }
  ],
  ja: [
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "わたしは がくせい ___ 。(Tôi là học sinh)",
      options: ["です", "ます", "を", "が"],
      answer: 0,
      note: 'Câu khẳng định lịch sự với danh từ kết thúc bằng "です" (desu).'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: '「ありがとう」(Arigatou) có nghĩa là gì?',
      options: ["Xin lỗi", "Cảm ơn", "Chào bạn", "Tạm biệt"],
      answer: 1,
      note: 'ありがとう = Cảm ơn, すみません = Xin lỗi / Làm phiền.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "Chọn trợ từ đúng: パン ___ たべます。(Tôi ăn bánh mì)",
      options: ["を", "に", "へ", "で"],
      answer: 0,
      note: 'Trợ từ を (đọc là o) đứng sau tân ngữ trực tiếp chịu tác động của hành động.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Số 3 trong tiếng Nhật là:',
      options: ["さん (san)", "に (ni)", "し (shi)", "ご (go)"],
      answer: 0,
      note: 'いち (1), に (2), さん (3), よん/し (4), ご (5).'
    },
    {
      skill: 'reading',
      skillLabel: 'Đọc hiểu',
      prompt: 'Đọc: 「わたしは まいにち にほんごを べんきょうします。」',
      options: ["Tôi học tiếng Nhật mỗi ngày", "Tôi ăn cơm mỗi ngày", "Tôi đi học mỗi tuần", "Tôi học tiếng Anh hôm qua"],
      answer: 0,
      note: 'まいにち = mỗi ngày, にほんご = tiếng Nhật, べんきょうします = học.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "___ に いきますか。（Bạn đi đâu vậy?）",
      options: ["どこ", "なに", "だれ", "いつ"],
      answer: 0,
      note: 'どこ (doko) = ở đâu, なに = cái gì, だれ = ai, いつ = khi nào.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: '「ねこ」(Neko) là con gì?',
      options: ["Con chó", "Con mèo", "Con cá", "Con chim"],
      answer: 1,
      note: 'ねこ = con mèo, いぬ = con chó.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: 'Câu nào diễn đạt đúng "Đây là sách"?',
      options: ["これは ほんです", "これが ほんですか", "ほんは これです", "これに ほん"],
      answer: 0,
      note: 'これ (cái này) + は + ほん (sách) + です.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Tính từ 「おいしい」(Oishii) nghĩa là gì?',
      options: ["Đẹp", "Ngon", "Nóng", "Nhanh"],
      answer: 1,
      note: 'おいしい = ngon, かわいい = dễ thương.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: 'Dạng phủ định lịch sự của 「です」 là:',
      options: ["じゃありません", "でした", "ですか", "ですから"],
      answer: 0,
      note: 'です → phủ định là じゃありません (không phải là).'
    }
  ],
  ko: [
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "저는 학생 ___ 。(Tôi là học sinh)",
      options: ["입니다", "있습니다", "합니다", "좋아요"],
      answer: 0,
      note: '학생 (học sinh) + 입니다 (là) = 학생입니다.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: '「감사합니다」(Gamsahamnida) có nghĩa là gì?',
      options: ["Xin lỗi", "Cảm ơn", "Xin chào", "Tạm biệt"],
      answer: 1,
      note: '감사합니다 = Cảm ơn, 죄송합니다 = Xin lỗi.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Số 3 (Hán-Hàn) trong tiếng Hàn là:',
      options: ["삼 (sam)", "이 (i)", "사 (sa)", "오 (o)"],
      answer: 0,
      note: '일 (1), 이 (2), 삼 (3), 사 (4), 오 (5).'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "저는 밥 ___ 먹어요。(Tôi ăn cơm)",
      options: ["을", "에", "가", "도"],
      answer: 0,
      note: '밥 có patchim nên đi kèm tiểu từ tân ngữ 을.'
    },
    {
      skill: 'reading',
      skillLabel: 'Đọc hiểu',
      prompt: 'Đọc: 「저는 매일 한국어를 공부해요。」',
      options: ["Tôi học tiếng Hàn mỗi ngày", "Tôi học tiếng Hàn mỗi tuần", "Tôi dạy tiếng Hàn mỗi ngày", "Tôi nghe tiếng Hàn mỗi tối"],
      answer: 0,
      note: '매일 = mỗi ngày, 한국어 = tiếng Hàn, 공부해요 = học.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: '「고양이」(Goyangi) là con gì?',
      options: ["Con chó", "Con mèo", "Con chim", "Con cá"],
      answer: 1,
      note: '고양이 = con mèo, 강아지 = chó con.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ nào có nghĩa là "ngon miệng"?',
      options: ["맛있어요", "예뻐요", "바빠요", "추워요"],
      answer: 0,
      note: '맛있어요 = ngon, 맛없어요 = không ngon.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "이것 ___ 뭐예요？(Cái này là cái gì?)",
      options: ["은", "를", "에", "와"],
      answer: 0,
      note: '이것 có patchim ㅅ nên đi kèm tiểu từ chủ đề 은.'
    },
    {
      skill: 'vocab',
      skillLabel: 'Từ vựng',
      prompt: 'Từ để hỏi 「어디」(Eodi) nghĩa là gì?',
      options: ["Ở đâu", "Khi nào", "Ai", "Cái gì"],
      answer: 0,
      note: '어디 = ở đâu, 언제 = khi nào, 누구 = ai, 무엇 = cái gì.'
    },
    {
      skill: 'grammar',
      skillLabel: 'Ngữ pháp',
      prompt: "저는 학교 ___ 가요。(Tôi đi đến trường)",
      options: ["에", "를", "도", "만"],
      answer: 0,
      note: 'Đi đến một địa điểm nào đó dùng tiểu từ hướng đến 에 (학교에 가요).'
    }
  ]
};

const LEVEL_DEFINITIONS = {
  starter: {
    level: 'starter',
    label: 'Khởi đầu mới (Mất gốc)',
    badge: '🌱 Hạt Mầm',
    note: 'Không sao cả! Bạn Trọng và Bắp sẽ đồng hành từ những viên gạch đầu tiên, mỗi bài 5 phút, không áp lực.',
    recommendation: 'Tập trung học cách phát âm chuẩn và 6 từ vựng quen thuộc quanh trường học.'
  },
  foundation: {
    level: 'foundation',
    label: 'Đang xây nền',
    badge: '🌿 Chồi Non',
    note: 'Bạn đã có một chút cảm giác ngôn ngữ. Hãy tập ghép từ thành câu đơn giản và luyện nói cùng AI.',
    recommendation: 'Ôn tập ngắt quãng 70% từ vựng và 30% làm bài tập ngắn theo nguyên tắc 70/30.'
  },
  elementary: {
    level: 'elementary',
    label: 'Sắp vững cơ bản',
    badge: '🌾 Vươn Cao',
    note: 'Nền tảng khá tốt! Giờ là lúc vá lại những chỗ ngữ pháp còn lấn cấn và tăng tốc phản xạ giao tiếp.',
    recommendation: 'Thử phương pháp Feynman "Dạy lại cho Bắp" để khắc sâu kiến thức vào trí nhớ dài hạn.'
  },
  intermediate: {
    level: 'intermediate',
    label: 'Khá vững vàng',
    badge: '🍞 Ổ Bánh Mì Vàng Giòn',
    note: 'Rất tuyệt vời! Bạn hoàn toàn có thể tự tin giao tiếp đời sống và chuẩn bị chuẩn đầu ra đại học.',
    recommendation: 'Luyện nói tự do với bạn AI và tra cứu chuyên sâu các mẫu ngữ pháp nâng cao.'
  }
};

// 36 Grammar Lessons across 4 languages
const GRAMMAR_LIBRARY = {
  en: [
    {
      id: 'en_svo',
      level: 'A1',
      title: 'Trật tự câu cơ bản: S + V + O',
      desc: 'Khác với tiếng Việt, tiếng Anh luôn cần chủ ngữ và động từ rõ ràng.',
      formula: 'Chủ ngữ (Subject) + Động từ (Verb) + Tân ngữ (Object)',
      explanation: 'Tiếng Anh gần như không bao giờ lược bỏ chủ ngữ. Nếu câu không có chủ ngữ tự nhiên, ta dùng chủ ngữ giả (It is raining) hoặc There is/are. Tính từ luôn đứng trước danh từ (a warm banh mi).',
      examples: [
        { en: "I drink coffee every morning.", vi: "Tôi uống cà phê mỗi sáng." },
        { en: "She speaks English very clearly.", vi: "Cô ấy nói tiếng Anh rất rõ ràng." }
      ],
      tip: 'Trạng từ chỉ thời gian thường đứng ở cuối hoặc đầu câu; trạng từ tần suất đứng trước động từ thường.'
    },
    {
      id: 'en_present_simple',
      level: 'A1',
      title: 'Thì hiện tại đơn (Present Simple)',
      desc: 'Dùng cho thói quen, lịch trình cố định và sự thật hiển nhiên.',
      formula: 'S + V(s/es) | S + do/does not + V-bare | Do/Does + S + V-bare?',
      explanation: 'Với I/you/we/they động từ giữ nguyên. Với he/she/it thêm -s/-es. Đây là thì dùng nhiều nhất trong sinh hoạt hằng ngày của sinh viên.',
      examples: [
        { en: "She works at a campus café.", vi: "Cô ấy làm việc tại một quán cà phê trong trường." },
        { en: "Do you study in the library at night?", vi: "Bạn có hay học ở thư viện vào buổi tối không?" }
      ],
      tip: 'Không dùng hiện tại đơn cho việc đang diễn ra ngay lúc nói — việc đó dùng hiện tại tiếp diễn.'
    },
    {
      id: 'en_articles',
      level: 'A1',
      title: 'Mạo từ: a / an / the',
      desc: 'Cách dùng a/an cho danh từ nhắc lần đầu, the cho danh từ đã xác định.',
      formula: 'a + phụ âm | an + nguyên âm (u, e, o, a, i) | the + vật đã rõ',
      explanation: 'Chọn a hay an căn cứ theo phiên âm phát âm, không phải mặt chữ viết (ví dụ: an hour vì h câm, nhưng a university vì âm /j/).',
      examples: [
        { en: "I bought a banh mi. The banh mi was crispy.", vi: "Mình mua một ổ bánh mì. Ổ bánh mì đó rất giòn." },
        { en: "Water is essential for life.", vi: "Nước rất cần thiết cho sự sống (danh từ chung không dùng mạo từ)." }
      ],
      tip: 'Không dùng the trước tên quốc gia (trừ the USA, the UK) hoặc tên ngôn ngữ thông thường.'
    },
    {
      id: 'en_present_perfect',
      level: 'A2',
      title: 'Hiện tại hoàn thành vs Quá khứ đơn',
      desc: 'Phân biệt hành động đã kết thúc và hành động còn liên hệ với hiện tại.',
      formula: 'Present Perfect: have/has + V3/ed | Past Simple: V2/ed',
      explanation: 'Quá khứ đơn cần mốc thời gian đã qua cụ thể (yesterday, last week). Hiện tại hoàn thành dùng khi thời điểm không quan trọng hoặc hành động kéo dài đến nay.',
      examples: [
        { en: "I have just finished my assignment.", vi: "Mình vừa mới làm xong bài tập được giao." },
        { en: "I finished my assignment at 10 PM last night.", vi: "Mình đã làm xong bài tập lúc 10 giờ tối qua." }
      ],
      tip: 'Từ nhận biết Present Perfect: just, already, yet, since, for, ever, never.'
    },
    {
      id: 'en_conditionals',
      level: 'B1',
      title: 'Câu điều kiện loại 1 & loại 2',
      desc: 'Giả định có thật trong tương lai vs Giả định trái ngược thực tế hiện tại.',
      formula: 'Loại 1: If + V(hiện tại), will + V | Loại 2: If + V(quá khứ), would + V',
      explanation: 'Loại 1 nói khả năng có thể xảy ra. Loại 2 nói điều tưởng tượng không có thật ở hiện tại, trong văn phong chuẩn to be dùng were cho mọi ngôi (If I were you).',
      examples: [
        { en: "If it rains tomorrow, we will study online.", vi: "Nếu mai mưa, chúng mình sẽ học trực tuyến." },
        { en: "If I had more free time, I would learn Spanish.", vi: "Nếu mình có nhiều thời gian rảnh hơn, mình sẽ học tiếng Tây Ban Nha." }
      ],
      tip: 'Không bao giờ đặt will hoặc would ngay trong mệnh đề có chữ If.'
    },
    {
      id: 'en_passive',
      level: 'B1',
      title: 'Câu bị động (Passive Voice)',
      desc: 'Nhấn mạnh đối tượng chịu tác động hoặc khi người thực hiện không quan trọng.',
      formula: 'S + to be (chia theo thì) + V3/ed (+ by O)',
      explanation: 'Rất hay gặp trong bài đọc học thuật, bài giảng đại học và đề thi chuẩn đầu ra.',
      examples: [
        { en: "The assignment must be submitted before Friday.", vi: "Bài tập phải được nộp trước thứ Sáu." },
        { en: "This university was founded in 2020.", vi: "Trường đại học này được thành lập vào năm 2020." }
      ],
      tip: 'Chỉ ngoại động từ (động từ có tân ngữ theo sau) mới chuyển được sang thể bị động.'
    }
  ],
  zh: [
    {
      id: 'zh_svo',
      level: 'A1',
      title: 'Trật tự câu cơ bản & chữ 是',
      desc: 'Tiếng Trung không chia thì hay biến đổi hình thái động từ.',
      formula: 'Chủ ngữ + Động từ + Tân ngữ (S + V + O)',
      explanation: 'Thời gian được biểu thị bằng trạng từ (hôm qua, ngày mai, đang, đã). Tính từ tự làm vị ngữ được mà không cần chữ 是 (Ví dụ: 我很累 = Tôi rất mệt, không nói 我是很累).',
      examples: [
        { zh: "我是大学生。", pinyin: "Wǒ shì dàxuéshēng.", vi: "Tôi là sinh viên đại học." },
        { zh: "今天很热。", pinyin: "Jīntiān hěn rè.", vi: "Hôm nay rất nóng (không dùng 是)." }
      ],
      tip: 'Phủ định của 是 là 不是 (bú shì); phủ định của 有 là 没有 (méi yǒu).'
    },
    {
      id: 'zh_measure_words',
      level: 'A1',
      title: 'Lượng từ (量词) trong tiếng Trung',
      desc: 'Danh từ tiếng Trung bắt buộc phải có lượng từ đứng trước.',
      formula: 'Số từ + Lượng từ + Danh từ',
      explanation: 'Không nói "một sách" mà phải nói "một cuốn sách" (一本书). Lượng từ phổ biến nhất dùng cho mọi thứ khi chưa nhớ lượng từ riêng là 个 (gè).',
      examples: [
        { zh: "两本书", pinyin: "Liǎng běn shū", vi: "Hai cuốn sách (dùng 两 thay vì 二 trước lượng từ)." },
        { zh: "一杯咖啡", pinyin: "Yì bēi kāfēi", vi: "Một ly cà phê." }
      ],
      tip: 'Trước lượng từ, số 2 luôn đọc là 两 (liǎng), không dùng 二 (èr).'
    },
    {
      id: 'zh_three_de',
      level: 'A2',
      title: 'Bộ ba trợ từ: 的 · 地 · 得',
      desc: 'Cùng phát âm là "de" nhưng giữ ba vai trò ngữ pháp hoàn toàn khác nhau.',
      formula: 'Tính từ + 的 + Danh từ | Tính từ + 地 + Động từ | Động từ + 得 + Bổ ngữ',
      explanation: 'Mẹo nhớ: Trước danh từ dùng 的 (我的书), trước động từ diễn tả dáng vẻ dùng 地 (慢慢地走), sau động từ đánh giá kết quả dùng 得 (跑得很快).',
      examples: [
        { zh: "她的汉语说得非常好。", pinyin: "Tā de hànyǔ shuō de fēicháng hǎo.", vi: "Tiếng Trung của cô ấy nói rất hay." },
        { zh: "他高兴地笑了。", pinyin: "Tā gāoxìng de xiào le.", vi: "Anh ấy cười một cách vui vẻ." }
      ],
      tip: 'Trong xưng hô thân mật gia đình, chữ 的 có thể lược bỏ (我妈妈 thay vì 我的妈妈).'
    }
  ],
  ja: [
    {
      id: 'ja_sov',
      level: 'A1',
      title: 'Trật tự câu SOV & Trợ từ は / が',
      desc: 'Động từ luôn đứng cuối câu. Trợ từ xác định vai trò của từ đứng trước.',
      formula: 'Chủ đề + は + Tân ngữ + を + Động từ',
      explanation: 'は (đọc là wa) đánh dấu chủ đề đã biết của cuộc trò chuyện. が đánh dấu chủ thể thực hiện hành động hoặc thông tin mới xuất hiện.',
      examples: [
        { ja: "わたしはベトナム人です。", romaji: "Watashi wa Betonamujin desu.", vi: "Tôi là người Việt Nam." },
        { ja: "だれが来ましたか。", romaji: "Dare ga kimashita ka?", vi: "Ai đã đến thế? (Hỏi ai dùng が)." }
      ],
      tip: 'Đừng dịch は là "là", は chỉ là biển báo giao thông báo hiệu "đây là chủ đề".'
    },
    {
      id: 'ja_particles',
      level: 'A1',
      title: 'Bộ ba trợ từ: を · に · で',
      desc: 'Chỉ đối tượng, thời gian/đích đến và địa điểm hành động.',
      formula: 'Tân ngữ + を | Giờ/Nơi đến + に | Nơi hành động/Phương tiện + で',
      explanation: 'Phân biệt に và で: に là nơi tồn tại tĩnh (ở thư viện có sách), で là nơi diễn ra hành động động (ở thư viện học bài).',
      examples: [
        { ja: "毎朝パンを食べます。", romaji: "Maiasa pan o tabemasu.", vi: "Mỗi sáng tôi ăn bánh mì." },
        { ja: "図書館で勉強します。", romaji: "Toshokan de benkyou shimasu.", vi: "Tôi học bài ở thư viện." }
      ],
      tip: 'Đi lại bằng phương tiện gì dùng で: バイクで行きます (Đi bằng xe máy).'
    }
  ],
  ko: [
    {
      id: 'ko_sov',
      level: 'A1',
      title: 'Trật tự câu SOV & Đuôi câu 아요/어요',
      desc: 'Động từ nằm cuối câu và chia theo mức độ thân mật lịch sự.',
      formula: 'Chủ ngữ + 은/는 (hoặc 이/가) + Tân ngữ + 을/를 + Động từ',
      explanation: 'Nếu gốc động từ có nguyên âm ㅏ hoặc ㅗ thì cộng 아요; các nguyên âm khác cộng 어요; động từ 하다 biến thành 해요.',
      examples: [
        { ko: "저는 매일 한국어를 공부해요.", romaja: "Jeoneun maeil hangugeoreul gongbuhaeyo.", vi: "Tôi học tiếng Hàn mỗi ngày." },
        { ko: "친구가 커피를 마셔요.", romaja: "Chinguga keopireul masyeoyo.", vi: "Bạn tôi uống cà phê." }
      ],
      tip: 'Từ có phụ âm cuối (patchim) dùng 은 / 이 / 을; không có patchim dùng 는 / 가 / 를.'
    },
    {
      id: 'ko_particles',
      level: 'A1',
      title: 'Tiểu từ vị trí: 에 vs 에서',
      desc: 'Điểm đến, thời gian (에) vs Nơi diễn ra hành động (에서).',
      formula: 'Địa điểm + 에 (đến / tồn tại) | Địa điểm + 에서 (hành động diễn ra)',
      explanation: '학교에 가요 (Đi đến trường - đích đến), nhưng 학교에서 공부해요 (Học bài tại trường - nơi diễn ra hành động).',
      examples: [
        { ko: "도서관에 가요.", romaja: "Doseogwane gayo.", vi: "Tôi đi đến thư viện." },
        { ko: "도서관에서 책을 읽어요.", romaja: "Doseogwaneseo chaegeul ilgeoyo.", vi: "Tôi đọc sách ở thư viện." }
      ],
      tip: 'Từ 에서 còn có nghĩa là "từ đâu đó": 베트남에서 왔어요 (Tôi đến từ Việt Nam).'
    }
  ]
};

// 100+ Vocabulary Bank (with audio, IPA, and campus-friendly examples)
const VOCABULARY_BANKS = {
  en: [
    { id: 'v_en_1', word: 'assignment', ipa: '/əˈsaɪnmənt/', vi: 'bài tập được giao', topic: 'Trường học', example: 'I finished my assignment.', exVi: 'Mình đã làm xong bài tập.', level: 'A2' },
    { id: 'v_en_2', word: 'library', ipa: '/ˈlaɪbrəri/', vi: 'thư viện', topic: 'Trường học', example: 'Let us meet at the library.', exVi: 'Gặp nhau ở thư viện nhé.', level: 'A1' },
    { id: 'v_en_3', word: 'dormitory', ipa: '/ˈdɔːrmətɔːri/', vi: 'ký túc xá', topic: 'Trường học', example: 'My dorm is near the school.', exVi: 'Ký túc xá của mình ở gần trường.', level: 'A2' },
    { id: 'v_en_4', word: 'presentation', ipa: '/ˌpreznˈteɪʃn/', vi: 'bài thuyết trình', topic: 'Trường học', example: 'We have a presentation today.', exVi: 'Hôm nay nhóm mình có bài thuyết trình.', level: 'B1' },
    { id: 'v_en_5', word: 'deadline', ipa: '/ˈdedlaɪn/', vi: 'hạn chót nộp bài', topic: 'Trường học', example: 'The deadline is tonight.', exVi: 'Hạn chót là tối nay rồi.', level: 'A2' },
    { id: 'v_en_6', word: 'delicious', ipa: '/dɪˈlɪʃəs/', vi: 'ngon miệng', topic: 'Ẩm thực', example: 'This banh mi is so delicious!', exVi: 'Ổ bánh mì này ngon thật sự!', level: 'A1' },
    { id: 'v_en_7', word: 'iced coffee', ipa: '/aɪst ˈkɔːfi/', vi: 'cà phê sữa đá', topic: 'Ẩm thực', example: 'One Vietnamese iced coffee, please.', exVi: 'Cho mình một ly cà phê sữa đá nhé.', level: 'A1' },
    { id: 'v_en_8', word: 'bill', ipa: '/bɪl/', vi: 'hóa đơn tính tiền', topic: 'Ẩm thực', example: 'Can I have the bill, please?', exVi: 'Cho mình xin hóa đơn thanh toán với ạ.', level: 'A1' },
    { id: 'v_en_9', word: 'bus stop', ipa: '/ˈbʌs stɑːp/', vi: 'trạm dừng xe buýt', topic: 'Đi lại', example: 'Where is the nearest bus stop?', exVi: 'Trạm xe buýt gần nhất ở đâu vậy?', level: 'A1' },
    { id: 'v_en_10', word: 'confidence', ipa: '/ˈkɑːnfɪdəns/', vi: 'sự tự tin', topic: 'Cảm xúc', example: 'Speaking English needs confidence.', exVi: 'Nói tiếng Anh cần nhất là sự tự tin.', level: 'B1' }
  ],
  zh: [
    { id: 'v_zh_1', word: '同学', pinyin: 'tóngxué', vi: 'bạn cùng lớp', topic: 'Trường học', example: '我们是同班同学。', exVi: 'Chúng mình là bạn cùng lớp.', level: 'A1' },
    { id: 'v_zh_2', word: '作业', pinyin: 'zuòyè', vi: 'bài tập về nhà', topic: 'Trường học', example: '今天的作业很多。', exVi: 'Bài tập hôm nay nhiều ghê.', level: 'A1' },
    { id: 'v_zh_3', word: '图书馆', pinyin: 'túshūguǎn', vi: 'thư viện', topic: 'Trường học', example: '去图书馆看书吧。', exVi: 'Đi thư viện đọc sách đi.', level: 'A1' },
    { id: 'v_zh_4', word: '老师', pinyin: 'lǎoshī', vi: 'thầy cô giáo', topic: 'Trường học', example: '老师讲课很清楚。', exVi: 'Thầy giảng bài rất rõ ràng.', level: 'A1' },
    { id: 'v_zh_5', word: '面包', pinyin: 'miànbāo', vi: 'bánh mì', topic: 'Ẩm thực', example: '早餐吃面包。', exVi: 'Bữa sáng ăn bánh mì.', level: 'A1' },
    { id: 'v_zh_6', word: '多少钱', pinyin: 'duōshao qián', vi: 'bao nhiêu tiền', topic: 'Mua sắm', example: '这个多少钱？', exVi: 'Cái này bao nhiêu tiền vậy ạ?', level: 'A1' },
    { id: 'v_zh_7', word: '加油', pinyin: 'jiāyóu', vi: 'cố lên, nỗ lực', topic: 'Cảm xúc', example: '考试加油！', exVi: 'Thi cử cố lên nhé!', level: 'A1' }
  ],
  ja: [
    { id: 'v_ja_1', word: '学生', romaji: 'gakusei', vi: 'học sinh, sinh viên', topic: 'Trường học', example: 'わたしは大学の学生です。', exVi: 'Mình là sinh viên đại học.', level: 'A1' },
    { id: 'v_ja_2', word: '宿題', romaji: 'shukudai', vi: 'bài tập về nhà', topic: 'Trường học', example: '宿題が終わりました。', exVi: 'Mình đã làm xong bài tập rồi.', level: 'A1' },
    { id: 'v_ja_3', word: '図書館', romaji: 'toshokan', vi: 'thư viện', topic: 'Trường học', example: '図書館は静かです。', exVi: 'Thư viện rất yên tĩnh.', level: 'A1' },
    { id: 'v_ja_4', word: 'パン', romaji: 'pan', vi: 'bánh mì', topic: 'Ẩm thực', example: 'おいしいパンを食べます。', exVi: 'Ăn một ổ bánh mì ngon.', level: 'A1' },
    { id: 'v_ja_5', word: 'いくら', romaji: 'ikura', vi: 'bao nhiêu tiền', topic: 'Mua sắm', example: 'これはいくらですか。', exVi: 'Cái này giá bao nhiêu vậy?', level: 'A1' },
    { id: 'v_ja_6', word: '大丈夫', romaji: 'daijoubu', vi: 'không sao, ổn cả', topic: 'Cảm xúc', example: '間違えても大丈夫です！', exVi: 'Nói sai cũng không sao hết!', level: 'A1' }
  ],
  ko: [
    { id: 'v_ko_1', word: '대학생', romaja: 'daehaksaeng', vi: 'sinh viên đại học', topic: 'Trường học', example: '저는 대학교 1학년입니다.', exVi: 'Mình là sinh viên năm nhất.', level: 'A1' },
    { id: 'v_ko_2', word: '숙제', romaja: 'sukje', vi: 'bài tập', topic: 'Trường học', example: '오늘 숙제가 많아요.', exVi: 'Hôm nay nhiều bài tập ghê.', level: 'A1' },
    { id: 'v_ko_3', word: '도서관', romaja: 'doseogwan', vi: 'thư viện', topic: 'Trường học', example: '도서관에서 만나요.', exVi: 'Gặp nhau ở thư viện nhé.', level: 'A1' },
    { id: 'v_ko_4', word: '빵', romaja: 'ppang', vi: 'bánh mì', topic: 'Ẩm thực', example: '아침에 빵을 먹어요.', exVi: 'Buổi sáng mình ăn bánh mì.', level: 'A1' },
    { id: 'v_ko_5', word: '얼마예요', romaja: 'eolmayeyo', vi: 'bao nhiêu tiền', topic: 'Mua sắm', example: '이거 얼마예요?', exVi: 'Cái này bao nhiêu tiền ạ?', level: 'A1' },
    { id: 'v_ko_6', word: '화이팅', romaja: 'hwaiting', vi: 'cố lên!', topic: 'Cảm xúc', example: '오늘도 화이팅!', exVi: 'Hôm nay cũng cố lên nhé!', level: 'A1' }
  ]
};

// Phonetics Guide Data with Speakable Text
const PHONETICS_DATA = {
  en: [
    {
      category: 'Nguyên âm ngắn (Short Vowels)',
      sounds: [
        { symbol: '/ɪ/', word: 'sit', vi: 'i ngắn, giật nhẹ', speak: 'sit' },
        { symbol: '/e/', word: 'bed', vi: 'như e tiếng Việt', speak: 'bed' },
        { symbol: '/æ/', word: 'cat', vi: 'mở rộng miệng a bẹt', speak: 'cat' },
        { symbol: '/ʌ/', word: 'cup', vi: 'như á tiếng Việt', speak: 'cup' },
        { symbol: '/ɒ/', word: 'hot', vi: 'o ngắn tròn môi', speak: 'hot' },
        { symbol: '/ʊ/', word: 'book', vi: 'u ngắn, không chu môi', speak: 'book' },
        { symbol: '/ə/', word: 'about', vi: 'âm ơ lướt rất nhẹ (Schwa)', speak: 'about' }
      ]
    },
    {
      category: 'Nguyên âm dài (Long Vowels)',
      sounds: [
        { symbol: '/iː/', word: 'see', vi: 'i kéo dài, môi hơi cười', speak: 'see' },
        { symbol: '/ɑː/', word: 'car', vi: 'a dài, mở rộng cuống họng', speak: 'car' },
        { symbol: '/ɔː/', word: 'more', vi: 'o dài tròn môi', speak: 'more' },
        { symbol: '/uː/', word: 'food', vi: 'u dài chu môi', speak: 'food' },
        { symbol: '/ɜː/', word: 'bird', vi: 'ơ dài uốn nhẹ lưỡi', speak: 'bird' }
      ]
    }
  ],
  zh: [
    {
      category: 'Thanh điệu (4 Thanh tiếng Trung)',
      sounds: [
        { symbol: 'Thanh 1 (mā)', word: '妈', vi: 'Cao và bằng phẳng (5-5)', speak: '妈' },
        { symbol: 'Thanh 2 (má)', word: '麻', vi: 'Đi lên như dấu sắc (3-5)', speak: '麻' },
        { symbol: 'Thanh 3 (mǎ)', word: '马', vi: 'Xuống thấp rồi lên (2-1-4)', speak: '马' },
        { symbol: 'Thanh 4 (mà)', word: '骂', vi: 'Giật mạnh dứt khoát (5-1)', speak: '骂' }
      ]
    }
  ],
  ja: [
    {
      category: '5 Nguyên âm nền tảng (A - I - U - E - O)',
      sounds: [
        { symbol: 'あ (a)', word: 'あ', vi: 'Phát âm a gọn ghẽ', speak: 'あ' },
        { symbol: 'い (i)', word: 'い', vi: 'Phát âm i môi dẹt', speak: 'い' },
        { symbol: 'う (u)', word: 'う', vi: 'Phát âm u hơi lai ư, không chu môi', speak: 'う' },
        { symbol: 'え (e)', word: 'え', vi: 'Phát âm e ngắn rõ', speak: 'え' },
        { symbol: 'お (o)', word: 'お', vi: 'Phát âm o tròn môi', speak: 'お' }
      ]
    }
  ],
  ko: [
    {
      category: 'Nguyên âm cơ bản (Hangul Vowels)',
      sounds: [
        { symbol: 'ㅏ (a)', word: '아', vi: 'như a tiếng Việt', speak: '아' },
        { symbol: 'ㅓ (eo)', word: '어', vi: 'như ơ/o mở miệng', speak: '어' },
        { symbol: 'ㅗ (o)', word: '오', vi: 'o chu tròn môi', speak: '오' },
        { symbol: 'ㅜ (u)', word: '우', vi: 'u chu môi tới trước', speak: '우' },
        { symbol: 'ㅡ (eu)', word: '으', vi: 'ư môi bẹt kéo về sau', speak: '으' },
        { symbol: 'ㅣ (i)', word: '이', vi: 'i kéo khóe miệng', speak: '이' }
      ]
    }
  ]
};

// 6 Student-Life AI Buddy Conversational Topics
const AI_TOPICS = [
  {
    id: 'intro',
    title: 'Giới thiệu bản thân',
    hint: 'Tên, tuổi, trường, sở thích',
    emoji: '🙋',
    situation: 'Hai bạn mới quen nhau trong buổi sinh hoạt lớp đầu năm và đang hỏi thăm làm quen.',
    starters: {
      en: "Hi! Nice to meet you. I'm Alex from the English Club. What's your name?",
      zh: "你好！很高兴认识你。我叫李明，你叫什么名字？",
      ja: "はじめまして！わたしはケンです。おなまえはなんですか。",
      ko: "안녕하세요! 만나서 반가워요. 저는 민수예요. 이름이 뭐예요?"
    },
    hints: [
      { text: "My name is Trong. I study at MIT University.", vi: "Mình tên Trọng, là sinh viên trường MIT." },
      { text: "Nice to meet you too! I'm a first-year student.", vi: "Rất vui được gặp bạn! Mình là sinh viên năm nhất." }
    ]
  },
  {
    id: 'weekend',
    title: 'Cuối tuần của bạn',
    hint: 'Kể về việc bạn làm ngày nghỉ',
    emoji: '🌤️',
    situation: 'Bạn bè ngồi nói chuyện vào thứ Sáu, hỏi nhau cuối tuần này có kế hoạch gì vui không.',
    starters: {
      en: "Hey! Do you have any plans for this weekend?",
      zh: "周末你有什么打算吗？",
      ja: "週末はなにか予定がありますか。",
      ko: "이번 주말에 특별한 계획 있어요?"
    },
    hints: [
      { text: "I usually sleep in and go for coffee with friends.", vi: "Mình thường ngủ nướng rồi đi cà phê với bạn bè." },
      { text: "I plan to study at the library on Saturday.", vi: "Thứ Bảy mình định ra thư viện tự học." }
    ]
  },
  {
    id: 'cafe',
    title: 'Gọi món ở quán cà phê',
    hint: 'Gọi đồ uống, hỏi giá, bánh mì',
    emoji: '☕',
    situation: 'Bạn đang ở quầy cà phê gần trường, gọi đồ uống và trò chuyện thân mật.',
    starters: {
      en: "Welcome to Banh Mi Café! What can I get for you today?",
      zh: "欢迎光临！今天你想喝点什么？",
      ja: "いらっしゃいませ！ご注文はお決まりですか。",
      ko: "어서 오세요! 무엇을 주문하시겠어요?"
    },
    hints: [
      { text: "Can I have one iced coffee and a warm banh mi?", vi: "Cho mình một cà phê sữa đá và một bánh mì nóng nhé." },
      { text: "How much is this in total?", vi: "Tất cả hết bao nhiêu tiền vậy ạ?" }
    ]
  },
  {
    id: 'directions',
    title: 'Hỏi đường trong khuôn viên',
    hint: 'Tìm thư viện, phòng học',
    emoji: '🗺️',
    situation: 'Bạn là sinh viên mới, bị lạc khi tìm thư viện và hỏi một bạn đang đi trên sân trường.',
    starters: {
      en: "Excuse me! Are you looking for a classroom or the library?",
      zh: "请问，你在找教学楼还是图书馆？",
      ja: "すみません、図書館を探していますか。",
      ko: "실례지만, 도서관을 찾고 계세요?"
    },
    hints: [
      { text: "Could you tell me where the library is?", vi: "Bạn chỉ giúp mình thư viện ở đâu với được không?" },
      { text: "Is it on the second floor?", vi: "Nó ở trên tầng hai phải không bạn?" }
    ]
  },
  {
    id: 'class',
    title: 'Buổi học trên lớp',
    hint: 'Môn học, thầy cô, bài tập',
    emoji: '📚',
    situation: 'Hai bạn vừa tan giờ học trên lớp, ngồi nói chuyện về bài giảng và bài tập về nhà.',
    starters: {
      en: "Today's lecture was quite fast, right? Did you finish the notes?",
      zh: "今天老师讲得挺快的，你笔记记完了吗？",
      ja: "今日の授業はちょっと早かったですね。ノートは書けましたか。",
      ko: "오늘 수업 좀 빨랐죠? 필기 다 했어요?"
    },
    hints: [
      { text: "Yes, it was fast! Can we review the slides together?", vi: "Nhanh thật đấy! Lát nữa tụi mình cùng xem lại slide nhé?" },
      { text: "The lecturer gave us an assignment due Friday.", vi: "Thầy giao bài tập hạn chót là thứ Sáu này." }
    ]
  },
  {
    id: 'plans',
    title: 'Kế hoạch sau giờ học',
    hint: 'Đi ăn, học nhóm, về nhà',
    emoji: '🌙',
    situation: 'Tan học buổi chiều tối, rủ nhau đi ăn bánh mì hay về ký túc xá nghỉ ngơi.',
    starters: {
      en: "Classes are done for today! Want to grab some banh mi together?",
      zh: "下课啦！要不要一起去吃个面包？",
      ja: "授業が終わりましたね！一緒にパンを食べに行きませんか。",
      ko: "수업 끝났다! 같이 빵 먹으러 갈래요?"
    },
    hints: [
      { text: "Sounds great! I know a very good spot near campus.", vi: "Nghe tuyệt đấy! Mình biết một quán rất ngon ngay gần trường." },
      { text: "Let's go! I'm so hungry after class.", vi: "Đi thôi! Học xong đói meo rồi nè." }
    ]
  }
];

// Feynman Technique Prompts ("Dạy lại cho Bắp")
const FEYNMAN_PROMPTS = [
  {
    id: 'feynman_1',
    mascotQuestion: "Anh/Chị ơi, em là Bắp nè! Em mới học tiếng Anh mà thấy người ta hay dùng 'a' với 'an'. Sao lúc thì dùng 'a university' mà lúc lại 'an hour' vậy ạ?",
    keywords: ["nguyên âm", "phát âm", "âm đầu", "phiên âm", "giờ", "câm"],
    praise: "Oa! Bắp hiểu rồi! Căn cứ theo cách đọc phát âm chứ không phải chữ cái viết! Cảm ơn anh/chị nhiều nha!",
    encourage: "Bắp hơi lơ mơ xíu, anh/chị giảng thêm về chữ 'h câm' hoặc 'âm phát âm' xem sao nha!"
  },
  {
    id: 'feynman_2',
    mascotQuestion: "Bắp hay bị nhầm thì Quá khứ đơn với Hiện tại hoàn thành quá! Khi nào thì mình nói 'I finished' và khi nào nói 'I have finished' vậy ạ?",
    keywords: ["thời gian", "kết thúc", "hôm qua", "yesterday", "hiện tại", "vừa mới", "mốc"],
    praise: "Hay quá! Cứ có mốc giờ cụ thể trong quá khứ là dùng Quá khứ đơn, còn vừa mới xong hoặc còn dính tới bây giờ là Hiện tại hoàn thành!",
    encourage: "Anh/Chị cho Bắp thêm một ví dụ có chữ 'yesterday' hoặc 'just' để Bắp dễ nhớ hơn với!"
  }
];

// Project Credits & Metadata
const PROJECT_CREDITS = {
  course: 'Tư duy thiết kế và đổi mới sáng tạo',
  university: 'Vietnam MIT University',
  team: 'Nhóm 7 - Quyết Chiến',
  topic: 'CAMPUS AND STUDENT LIFE - Hỗ trợ sinh viên gặp khó khăn trong việc học ngôn ngữ',
  members: [
    { name: 'NGUYỄN THẾ HUY', id: '1326110004', role: 'CEO', task: 'Bàn giao việc, điều chỉnh nội dung và thiết kế' },
    { name: 'TRẦN HUỲNH MINH ĐĂNG', id: '1326110015', role: 'CTO', task: 'Xây dựng nội dung học & kiến trúc hệ thống' },
    { name: 'ĐINH NGUYỄN PHÚC LỘC', id: '1326110040', role: 'Thư ký', task: 'Làm nội dung, kiểm tra chất lượng & thiết kế' },
    { name: 'NGUYỄN THIỆN PHÁT', id: '1326110058', role: 'CPO', task: 'Tìm kiếm tư liệu hình ảnh, xây dựng ý tưởng' },
    { name: 'NGUYỄN HỮU LỘC', id: '0026110118', role: 'CMO', task: 'Thiết kế trực quan Canva & truyền thông' }
  ],
  persona: {
    name: 'Lê Văn Trọng',
    age: 18,
    role: 'Sinh viên năm nhất - MIT University',
    pains: 'Bỏ ngang Duolingo vì streak tạo áp lực; học nhưng không hiểu bản chất; sợ sai, sợ bị phán xét; giảng viên giảng nhanh trên lớp.',
    goals: 'Đạt chuẩn đầu ra đại học, tự tin giao tiếp với người nước ngoài, có lộ trình cá nhân hóa nhẹ nhàng không áp lực.'
  }
};
