/**
 * BÁNH MÌ NGÔN NGỮ — Controller & Giao diện ứng dụng chính
 * Sản phẩm Tư duy thiết kế & Đổi mới sáng tạo — Nhóm 7 (Quyết Chiến)
 * Persona: Lê Văn Trọng (SV năm nhất MIT University)
 */

const App = {
  // Application State
  state: {
    currentRoute: 'dashboard',
    profile: null,
    diagnostic: null,
    roadmap: [],
    flashcards: [],
    streak: null,
    activeTopicId: 'intro',
    activeTopicLang: 'en',
    currentCardIndex: 0,
    isCardFlipped: false,
    pomodoro: {
      timeLeft: 25 * 60,
      initialTime: 25 * 60,
      isRunning: false,
      isBreak: false,
      intervalId: null
    },
    activeLesson: null,
    lessonStep: 0,
    feynmanChat: []
  },

  // 1. Khởi tạo ứng dụng
  init() {
    this.state.profile = Storage.getProfile();
    this.state.diagnostic = Storage.getDiagnostic();
    this.state.streak = Storage.getStreak();
    this.state.roadmap = Storage.getRoadmap(this.state.profile.language);
    this.state.flashcards = Storage.getFlashcards(this.state.profile.language);

    // Set Theme
    document.documentElement.setAttribute('data-theme', this.state.profile.theme || 'light');

    // Check if new user -> redirect to onboarding
    if (!this.state.profile.hasOnboarded) {
      this.navigate('onboarding');
    } else {
      this.navigate('dashboard');
    }

    this.bindGlobalEvents();
  },

  bindGlobalEvents() {
    // Navigation listeners
    document.querySelectorAll('[data-route]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        const route = el.getAttribute('data-route');
        this.navigate(route);
      });
    });

    // Language switch button
    const langBtn = document.getElementById('langSelectBtn');
    if (langBtn) {
      langBtn.addEventListener('click', () => this.openLanguageModal());
    }

    // Theme toggle
    const themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => this.toggleTheme());
    }
  },

  toggleTheme() {
    const newTheme = this.state.profile.theme === 'dark' ? 'light' : 'dark';
    this.state.profile = Storage.saveProfile({ theme: newTheme });
    document.documentElement.setAttribute('data-theme', newTheme);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.textContent = newTheme === 'dark' ? '☀️' : '🌙';
  },

  // 2. Bộ điều hướng Router
  navigate(route, params = {}) {
    this.state.currentRoute = route;

    // Update active nav class
    document.querySelectorAll('.nav-item, .bottom-nav-item').forEach(el => {
      if (el.getAttribute('data-route') === route) {
        el.classList.add('active');
      } else {
        el.classList.remove('active');
      }
    });

    const mainContainer = document.getElementById('mainContent');
    if (!mainContainer) return;

    window.scrollTo({ top: 0, behavior: 'smooth' });

    switch (route) {
      case 'onboarding':
        this.renderOnboarding(mainContainer);
        break;
      case 'dashboard':
        this.renderDashboard(mainContainer);
        break;
      case 'roadmap':
        this.renderRoadmap(mainContainer);
        break;
      case 'lesson':
        this.renderLesson(mainContainer, params.lessonId);
        break;
      case 'flashcards':
        this.renderFlashcards(mainContainer);
        break;
      case 'speaking':
        this.renderSpeaking(mainContainer);
        break;
      case 'library':
        this.renderLibrary(mainContainer);
        break;
      case 'pomodoro':
        this.renderPomodoro(mainContainer);
        break;
      case 'settings':
        this.renderSettings(mainContainer);
        break;
      case 'credits':
        this.renderCredits(mainContainer);
        break;
      default:
        this.renderDashboard(mainContainer);
    }
  },

  // 3. Màn hình Chào mừng & Kiểm tra Trình độ (Onboarding & Placement Test)
  renderOnboarding(container) {
    let currentStep = 0; // 0: intro, 1: survey, 2: placement test, 3: result
    let selectedLang = this.state.profile.language || 'en';
    let dailyMins = 10;
    let userName = this.state.profile.name || 'Lê Văn Trọng';
    let currentQ = 0;
    let userAnswers = [];

    const updateView = () => {
      if (currentStep === 0) {
        container.innerHTML = `
          <div style="max-width: 580px; margin: 40px auto; text-align: center;" class="card-soft">
            <img src="assets/logo.svg" alt="Bánh Mì Ngôn Ngữ" style="width: 80px; height: 80px; margin: 0 auto 16px;" />
            <h1 style="font-size: 26px; font-weight: 800; letter-spacing: -0.02em;">Bánh Mì Ngôn Ngữ</h1>
            <p class="text-muted mt-1" style="font-size: 15px;">Học ngoại ngữ mỗi ngày, không áp lực — Dành cho sinh viên mất gốc</p>

            <div style="margin: 28px 0; display: flex; flex-direction: column; gap: 14px; text-align: left;">
              <div style="display: flex; gap: 14px; align-items: flex-start; padding: 14px; background: var(--bg-subtle); border-radius: var(--radius-md);">
                <span style="font-size: 24px;">🥖</span>
                <div>
                  <h4 style="font-weight: 700; font-size: 15px;">Mỗi bài chỉ 5–10 phút</h4>
                  <p class="text-muted" style="font-size: 13px;">Vừa một chuyến xe buýt đến trường. Không học dồn, không mở sách dày.</p>
                </div>
              </div>

              <div style="display: flex; gap: 14px; align-items: flex-start; padding: 14px; background: var(--bg-subtle); border-radius: var(--radius-md);">
                <span style="font-size: 24px;">⏰</span>
                <div>
                  <h4 style="font-weight: 700; font-size: 15px;">Thẻ nhớ Spaced Repetition</h4>
                  <p class="text-muted" style="font-size: 13px;">Tự nhắc bạn ôn đúng lúc sắp quên theo mốc ngắt quãng, nhẹ nhàng không nhồi nhét.</p>
                </div>
              </div>

              <div style="display: flex; gap: 14px; align-items: flex-start; padding: 14px; background: var(--bg-subtle); border-radius: var(--radius-md);">
                <span style="font-size: 24px;">🤖</span>
                <div>
                  <h4 style="font-weight: 700; font-size: 15px;">Bạn AI luyện nói không phán xét</h4>
                  <p class="text-muted" style="font-size: 13px;">Trò chuyện bằng giọng nói, chấm điểm phát âm từng từ, giải tỏa nỗi sợ sai.</p>
                </div>
              </div>
            </div>

            <button id="btnStartSurvey" class="btn-primary" style="width: 100%; font-size: 16px;">
              Bắt đầu ngay · Miễn phí hoàn toàn 🚀
            </button>
            <p class="text-muted mt-3" style="font-size: 12px;">Đề tài tư duy thiết kế — Nhóm 7 (Quyết Chiến) MIT University</p>
          </div>
        `;
        document.getElementById('btnStartSurvey').onclick = () => {
          currentStep = 1;
          updateView();
        };
      } else if (currentStep === 1) {
        container.innerHTML = `
          <div style="max-width: 580px; margin: 30px auto;" class="card-soft">
            <span class="pill pill-primary">Bước 1 / 3 · Thiết lập lộ trình</span>
            <h2 style="font-size: 24px; font-weight: 800; margin-top: 10px;">Vài câu hỏi nhanh cùng bạn</h2>
            <p class="text-muted" style="font-size: 14px;">Để Bánh Mì Ngôn Ngữ chuẩn bị lộ trình vừa sức nhất với bạn.</p>

            <div style="margin-top: 24px;">
              <label style="font-weight: 700; font-size: 13px; text-transform: uppercase; color: var(--text-muted);">Tên hoặc biệt danh của bạn</label>
              <input type="text" id="inputName" class="chat-input" style="width: 100%; margin-top: 8px;" value="${userName}" placeholder="Nhập tên bạn..." />
            </div>

            <div style="margin-top: 20px;">
              <label style="font-weight: 700; font-size: 13px; text-transform: uppercase; color: var(--text-muted);">Ngôn ngữ bạn muốn học</label>
              <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 8px;">
                ${Object.values(LANGUAGES).map(lang => `
                  <button type="button" class="lang-option-btn card-soft" data-lang="${lang.code}" style="padding: 14px; text-align: left; display: flex; align-items: center; gap: 10px; border: 2px solid ${selectedLang === lang.code ? 'var(--primary)' : 'var(--border)'}; background: ${selectedLang === lang.code ? 'var(--primary-light)' : 'var(--surface)'};">
                    <span style="font-size: 26px;">${lang.flag}</span>
                    <div>
                      <div style="font-weight: 700; font-size: 14.5px;">${lang.label}</div>
                      <div class="text-muted" style="font-size: 11px;">${lang.native}</div>
                    </div>
                  </button>
                `).join('')}
              </div>
            </div>

            <div style="margin-top: 20px;">
              <label style="font-weight: 700; font-size: 13px; text-transform: uppercase; color: var(--text-muted);">Mỗi ngày bạn muốn dành bao nhiêu phút?</label>
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 8px;">
                ${[5, 10, 15].map(min => `
                  <button type="button" class="mins-btn btn-secondary" data-min="${min}" style="padding: 12px; font-weight: 700; ${dailyMins === min ? 'border-color: var(--primary); background: var(--primary-light); color: var(--primary);' : ''}">
                    ${min} phút
                  </button>
                `).join('')}
              </div>
            </div>

            <button id="btnGoToTest" class="btn-primary mt-6" style="width: 100%;">
              Tiếp tục · Kiểm tra trình độ (3 phút) 📝
            </button>
          </div>
        `;

        document.querySelectorAll('.lang-option-btn').forEach(btn => {
          btn.onclick = () => {
            selectedLang = btn.getAttribute('data-lang');
            updateView();
          };
        });

        document.querySelectorAll('.mins-btn').forEach(btn => {
          btn.onclick = () => {
            dailyMins = parseInt(btn.getAttribute('data-min'));
            updateView();
          };
        });

        document.getElementById('btnGoToTest').onclick = () => {
          userName = document.getElementById('inputName').value.trim() || 'Lê Văn Trọng';
          currentStep = 2;
          currentQ = 0;
          userAnswers = [];
          updateView();
        };
      } else if (currentStep === 2) {
        // Placement Test Questions
        const qList = PLACEMENT_QUESTIONS[selectedLang] || PLACEMENT_QUESTIONS.en;
        const q = qList[currentQ];

        container.innerHTML = `
          <div style="max-width: 600px; margin: 30px auto;" class="card-soft">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span class="pill pill-primary">Câu ${currentQ + 1} / ${qList.length}</span>
              <span class="pill">${q.skillLabel}</span>
            </div>

            <!-- Progress bar -->
            <div style="height: 6px; background: var(--bg-subtle); border-radius: var(--radius-pill); overflow: hidden; margin-bottom: 24px;">
              <div style="height: 100%; width: ${((currentQ) / qList.length) * 100}%; background: var(--primary); transition: width 0.3s ease;"></div>
            </div>

            <h3 style="font-size: 19px; font-weight: 700; line-height: 1.4; margin-bottom: 20px;">${q.prompt}</h3>

            <div style="display: flex; flex-direction: column; gap: 10px;">
              ${q.options.map((opt, oIdx) => `
                <button type="button" class="opt-btn btn-secondary" data-idx="${oIdx}" style="justify-content: flex-start; text-align: left; padding: 14px 18px; font-size: 15px;">
                  <span style="display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: var(--radius-pill); background: var(--bg-subtle); font-size: 12px; font-weight: 700; margin-right: 8px;">
                    ${['A', 'B', 'C', 'D'][oIdx]}
                  </span>
                  ${opt}
                </button>
              `).join('')}
            </div>

            <div id="testExplanation" style="display: none; margin-top: 20px; padding: 14px; background: var(--bg-subtle); border-radius: var(--radius-md); font-size: 13.5px;"></div>

            <button id="btnNextQuestion" class="btn-primary mt-4" style="width: 100%; display: none;">
              Câu tiếp theo ➔
            </button>
          </div>
        `;

        document.querySelectorAll('.opt-btn').forEach(btn => {
          btn.onclick = () => {
            const chosenIdx = parseInt(btn.getAttribute('data-idx'));
            userAnswers[currentQ] = chosenIdx;

            // Highlight correct / wrong
            document.querySelectorAll('.opt-btn').forEach((b, idx) => {
              b.disabled = true;
              if (idx === q.answer) {
                b.style.borderColor = 'var(--teal)';
                b.style.background = 'var(--teal-light)';
                b.style.color = 'var(--teal)';
                b.style.fontWeight = '700';
              } else if (idx === chosenIdx) {
                b.style.borderColor = 'var(--danger)';
                b.style.background = 'var(--danger-light)';
              }
            });

            // Show explanation
            const exp = document.getElementById('testExplanation');
            exp.style.display = 'block';
            exp.innerHTML = `<strong>💡 Giải thích:</strong> ${q.note}`;

            // Show Next Button
            const nextBtn = document.getElementById('btnNextQuestion');
            nextBtn.style.display = 'inline-flex';
            nextBtn.onclick = () => {
              if (currentQ < qList.length - 1) {
                currentQ += 1;
                updateView();
              } else {
                currentStep = 3;
                updateView();
              }
            };
          };
        });
      } else if (currentStep === 3) {
        // Evaluate Placement Result
        const qList = PLACEMENT_QUESTIONS[selectedLang] || PLACEMENT_QUESTIONS.en;
        let score = 0;
        qList.forEach((q, idx) => {
          if (userAnswers[idx] === q.answer) score += 1;
        });

        const pct = Math.round((score / qList.length) * 100);
        let levelKey = 'starter';
        if (pct >= 85) levelKey = 'intermediate';
        else if (pct >= 65) levelKey = 'elementary';
        else if (pct >= 35) levelKey = 'foundation';

        const levelInfo = LEVEL_DEFINITIONS[levelKey];

        // Save into storage
        Storage.saveProfile({
          name: userName,
          language: selectedLang,
          dailyMinutes: dailyMins,
          hasOnboarded: true
        });

        Storage.saveDiagnostic({
          completed: true,
          score: score,
          total: qList.length,
          pct: pct,
          level: levelKey,
          testedAt: new Date().toISOString()
        });

        // Regenerate roadmap & flashcards for selected language
        Storage.getRoadmap(selectedLang);
        Storage.getFlashcards(selectedLang);

        container.innerHTML = `
          <div style="max-width: 600px; margin: 30px auto; text-align: center;" class="card-soft">
            <span style="font-size: 48px;">🎉</span>
            <h2 style="font-size: 26px; font-weight: 800; margin-top: 8px;">Kết quả kiểm tra của bạn</h2>
            <p class="text-muted" style="font-size: 14px;">Điểm số: <strong>${score}/${qList.length} (${pct}%)</strong></p>

            <div style="margin: 24px 0; padding: 20px; background: var(--primary-light); border: 1.5px solid var(--primary-border); border-radius: var(--radius-lg); text-align: left;">
              <div style="display: flex; align-items: center; justify-content: space-between;">
                <span class="pill pill-primary">${levelInfo.badge}</span>
                <span style="font-weight: 700; color: var(--primary);">${levelInfo.label}</span>
              </div>
              <p style="margin-top: 12px; font-size: 14px; line-height: 1.6; color: var(--text-main);">
                ${levelInfo.note}
              </p>
              <div style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--primary-border); font-size: 13px; color: var(--primary); font-weight: 600;">
                🎯 Gợi ý cho bạn: ${levelInfo.recommendation}
              </div>
            </div>

            <div style="text-align: left; background: var(--bg-subtle); padding: 16px; border-radius: var(--radius-md); margin-bottom: 24px;">
              <h4 style="font-weight: 700; font-size: 14px; margin-bottom: 6px;">Lộ trình cá nhân hóa đã sẵn sàng:</h4>
              <ul style="font-size: 13px; color: var(--text-muted); padding-left: 20px; line-height: 1.6;">
                <li>3 Chặng học với 9 bài học ngắn (5–10 phút/ngày)</li>
                <li>Thực hành phương pháp Feynman "Dạy lại cho Bắp"</li>
                <li>Học tập trung cùng đồng hồ Pomodoro 25/5 & quy tắc 70/30</li>
              </ul>
            </div>

            <button id="btnEnterApp" class="btn-primary" style="width: 100%; font-size: 16px;">
              Vào Bảng điều khiển học tập ngay ➔
            </button>
          </div>
        `;

        document.getElementById('btnEnterApp').onclick = () => {
          this.init();
        };
      }
    };

    updateView();
  },

  // 4. Bảng điều khiển chính (Dashboard)
  renderDashboard(container) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const langInfo = LANGUAGES[lang] || LANGUAGES.en;
    const streak = Storage.getStreak();
    const roadmap = Storage.getRoadmap(lang);
    const dueCards = Storage.getDueCards(lang);

    // Find next undone lesson
    let nextLesson = null;
    let nextUnit = null;
    for (const unit of roadmap) {
      for (const les of unit.lessons) {
        if (!les.done) {
          nextLesson = les;
          nextUnit = unit;
          break;
        }
      }
      if (nextLesson) break;
    }

    // Daily quote
    const quotes = DAILY_QUOTES[lang] || DAILY_QUOTES.en;
    const todayQuote = quotes[new Date().getDate() % quotes.length];

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 24px;">
        <!-- Welcome Greeting -->
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
          <div>
            <h1 style="font-size: 26px; font-weight: 800; letter-spacing: -0.02em;">
              Chào bạn ${profile.name || 'Trọng'}! 👋
            </h1>
            <p class="text-muted" style="font-size: 14.5px;">
              Hôm nay cùng nhai một "ổ bánh mì" 5 phút thật giòn và nhẹ nhàng nhé!
            </p>
          </div>

          <div style="display: flex; gap: 10px;">
            <button class="pill pill-primary" id="btnPopQuiz">
              ⚡ Kiểm tra đột xuất (Pop Quiz)
            </button>
            <button class="pill" id="btnDashboardLang">
              ${langInfo.flag} ${langInfo.label}
            </button>
          </div>
        </div>

        <!-- Daily Motivational Quote -->
        <div class="quote-banner">
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
              <span class="pill pill-primary" style="font-size: 11px;">🍞 Châm ngôn mỗi ngày</span>
              <span class="text-muted" style="font-size: 12px;">— ${todayQuote.author}</span>
            </div>
            <h3 style="font-size: 17px; font-weight: 700; color: var(--primary); line-height: 1.4;">
              "${todayQuote.quote}"
            </h3>
            <p style="font-size: 14px; margin-top: 4px; color: var(--text-main);">
              ${todayQuote.vi}
            </p>
            <p class="text-muted" style="font-size: 12px; margin-top: 8px;">
              💡 <em>${todayQuote.tip}</em>
            </p>
          </div>

          <button class="btn-icon" id="btnSpeakQuote" title="Nghe phát âm chuẩn" style="background: var(--surface);">
            🔊
          </button>
        </div>

        <!-- Main Action Grid -->
        <div class="grid-2">
          <!-- Next Lesson Card -->
          <div class="card-soft" style="display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="pill pill-teal">Bài học hôm nay</span>
                <span class="text-muted" style="font-size: 12px;">⏱️ ${profile.dailyMinutes || 7} phút</span>
              </div>

              ${nextLesson ? `
                <h3 style="font-size: 19px; font-weight: 700; margin-top: 14px; line-height: 1.3;">
                  ${nextLesson.title}
                </h3>
                <p class="text-muted" style="font-size: 13.5px; margin-top: 6px;">
                  Chặng: ${nextUnit.title}
                </p>
                <div style="margin-top: 14px; display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--teal); font-weight: 600;">
                  <span>✨ Phương pháp Feynman: Có phần giảng lại cho Bắp</span>
                </div>
              ` : `
                <h3 style="font-size: 18px; font-weight: 700; margin-top: 14px; color: var(--success);">
                  🎉 Bạn đã hoàn thành toàn bộ 9 bài học!
                </h3>
                <p class="text-muted" style="font-size: 13px; margin-top: 6px;">
                  Hãy tiếp tục ôn luyện flashcard hoặc thi lại bài kiểm tra để nâng cấp trình độ.
                </p>
              `}
            </div>

            <div style="margin-top: 24px;">
              ${nextLesson ? `
                <button class="btn-primary" id="btnStartLesson" style="width: 100%;">
                  Bắt đầu học ngay ➔
                </button>
              ` : `
                <button class="btn-secondary" id="btnReviewAll" style="width: 100%;">
                  Ôn lại thẻ ghi nhớ
                </button>
              `}
            </div>
          </div>

          <!-- Gentle Streak & Status Card -->
          <div class="card-soft" style="display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="pill pill-primary">🔥 Chuỗi đều đặn (Streak)</span>
                <span style="font-weight: 800; font-size: 16px; color: var(--primary);">${streak.count} ngày</span>
              </div>

              <h4 style="font-size: 16px; font-weight: 700; margin-top: 14px;">
                Cứ thong thả, không cần học nhiều một lúc
              </h4>
              <p class="text-muted" style="font-size: 13px; margin-top: 6px; line-height: 1.5;">
                ${streak.message}
              </p>

              <div style="margin-top: 16px; padding: 12px; background: var(--bg-subtle); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: space-between;">
                <div>
                  <div style="font-weight: 700; font-size: 13.5px;">Sổ thẻ cần ôn hôm nay:</div>
                  <div class="text-muted" style="font-size: 12px;">Ôn ngắt quãng giúp nhớ từ vĩnh viễn</div>
                </div>
                <span class="pill pill-primary" style="font-size: 14px; font-weight: 800;">
                  ${dueCards.length} từ
                </span>
              </div>
            </div>

            <div style="margin-top: 24px; display: flex; gap: 10px;">
              <button class="btn-secondary" id="btnGoFlashcards" style="flex: 1;">
                Lật thẻ (${dueCards.length})
              </button>
              <button class="btn-teal" id="btnGoSpeaking" style="flex: 1;">
                Luyện nói AI 🎙️
              </button>
            </div>
          </div>
        </div>

        <!-- 3 Quick Features Row -->
        <div class="grid-3">
          <div class="card-soft" style="cursor: pointer;" id="cardPomodoroQuick">
            <span style="font-size: 28px;">⏱️</span>
            <h4 style="font-weight: 700; font-size: 15px; margin-top: 8px;">Đồng hồ Pomodoro 25/5</h4>
            <p class="text-muted" style="font-size: 12.5px; margin-top: 4px;">Áp dụng quy tắc 70/30 (70% ôn tập, 30% bài tập).</p>
          </div>

          <div class="card-soft" style="cursor: pointer;" id="cardLibraryQuick">
            <span style="font-size: 28px;">📖</span>
            <h4 style="font-weight: 700; font-size: 15px; margin-top: 8px;">Thư viện ngữ pháp & IPA</h4>
            <p class="text-muted" style="font-size: 12.5px; margin-top: 4px;">Tra cứu nhanh công thức câu & bảng phát âm chuẩn.</p>
          </div>

          <div class="card-soft" style="cursor: pointer;" id="cardCreditsQuick">
            <span style="font-size: 28px;">👥</span>
            <h4 style="font-weight: 700; font-size: 15px; margin-top: 8px;">Về Nhóm 7 (Quyết Chiến)</h4>
            <p class="text-muted" style="font-size: 12.5px; margin-top: 4px;">Đề tài Tư duy thiết kế cho SV Lê Văn Trọng.</p>
          </div>
        </div>
      </div>
    `;

    // Event listeners
    document.getElementById('btnSpeakQuote').onclick = () => {
      Speech.speak(todayQuote.speak, lang);
    };

    if (document.getElementById('btnStartLesson')) {
      document.getElementById('btnStartLesson').onclick = () => {
        this.navigate('lesson', { lessonId: nextLesson.id });
      };
    }

    if (document.getElementById('btnReviewAll')) {
      document.getElementById('btnReviewAll').onclick = () => this.navigate('flashcards');
    }

    document.getElementById('btnGoFlashcards').onclick = () => this.navigate('flashcards');
    document.getElementById('btnGoSpeaking').onclick = () => this.navigate('speaking');
    document.getElementById('btnDashboardLang').onclick = () => this.openLanguageModal();
    document.getElementById('btnPopQuiz').onclick = () => this.openPopQuizModal();

    document.getElementById('cardPomodoroQuick').onclick = () => this.navigate('pomodoro');
    document.getElementById('cardLibraryQuick').onclick = () => this.navigate('library');
    document.getElementById('cardCreditsQuick').onclick = () => this.navigate('credits');
  },

  // 5. Lộ trình học (Learning Path / Roadmap)
  renderRoadmap(container) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const langInfo = LANGUAGES[lang] || LANGUAGES.en;
    const roadmap = Storage.getRoadmap(lang);

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
          <div>
            <h1 style="font-size: 24px; font-weight: 800;">Lộ trình học cá nhân hóa</h1>
            <p class="text-muted" style="font-size: 14px;">9 bài học ngắn được chia nhỏ theo năng lực của bạn (${langInfo.label}).</p>
          </div>

          <button class="btn-secondary" id="btnRetakeTest">
            🔄 Làm lại kiểm tra
          </button>
        </div>

        <div style="display: flex; flex-direction: column; gap: 20px;">
          ${roadmap.map((unit, uIdx) => `
            <div class="card-soft">
              <div style="display: flex; justify-content: space-between; align-items: baseline; border-bottom: 1px solid var(--border-light); padding-bottom: 12px; margin-bottom: 14px;">
                <div>
                  <h3 style="font-size: 17px; font-weight: 700; color: var(--primary);">${unit.title}</h3>
                  <p class="text-muted" style="font-size: 13px;">Trọng tâm: ${unit.focus}</p>
                </div>
                <span class="pill pill-primary">Chặng ${uIdx + 1}</span>
              </div>

              <div style="display: flex; flex-direction: column; gap: 10px;">
                ${unit.lessons.map(les => `
                  <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: var(--bg-subtle); border-radius: var(--radius-md); transition: transform 0.15s ease;">
                    <div style="display: flex; align-items: center; gap: 12px;">
                      <span style="font-size: 20px;">${les.done ? '✅' : '📖'}</span>
                      <div>
                        <div style="font-weight: 700; font-size: 14.5px; ${les.done ? 'color: var(--text-muted); text-decoration: line-through;' : ''}">
                          ${les.title}
                        </div>
                        <div class="text-muted" style="font-size: 12px;">Thời lượng: ~${les.duration} phút</div>
                      </div>
                    </div>

                    <div>
                      ${les.done ? `
                        <span class="pill pill-teal">Đã xong (${les.score}đ)</span>
                      ` : `
                        <button class="btn-primary btn-lesson-start" data-lesson="${les.id}" style="padding: 8px 16px; font-size: 13px;">
                          Học bài ➔
                        </button>
                      `}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    document.querySelectorAll('.btn-lesson-start').forEach(btn => {
      btn.onclick = () => {
        const id = btn.getAttribute('data-lesson');
        this.navigate('lesson', { lessonId: id });
      };
    });

    document.getElementById('btnRetakeTest').onclick = () => {
      if (confirm('Bạn có muốn làm lại bài kiểm tra để đánh giá lại trình độ không?')) {
        this.navigate('onboarding');
      }
    };
  },

  // 6. Bài học tương tác & Phương pháp Feynman "Dạy lại cho Bắp"
  renderLesson(container, lessonId) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const vocabList = VOCABULARY_BANKS[lang] || VOCABULARY_BANKS.en;
    const sampleWords = vocabList.slice(0, 3);
    const feynmanData = FEYNMAN_PROMPTS[0];

    let currentStep = 0; // 0: vocab, 1: grammar, 2: feynman with mascot Bắp, 3: completed

    const updateLesson = () => {
      if (currentStep === 0) {
        // Step 1: Vocabulary
        container.innerHTML = `
          <div style="max-width: 620px; margin: 20px auto;" class="card-soft">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <span class="pill pill-primary">Phần 1/3 · Từ vựng cốt lõi</span>
              <span class="text-muted" style="font-size: 13px;">Chạm vào loa để nghe phát âm</span>
            </div>

            <h2 style="font-size: 22px; font-weight: 800; margin-bottom: 16px;">Từ vựng hôm nay (3 từ)</h2>

            <div style="display: flex; flex-direction: column; gap: 12px;">
              ${sampleWords.map(w => `
                <div style="padding: 16px; background: var(--bg-subtle); border-radius: var(--radius-md); display: flex; justify-content: space-between; align-items: center;">
                  <div>
                    <div style="display: flex; align-items: baseline; gap: 8px;">
                      <span style="font-size: 18px; font-weight: 800; color: var(--primary);">${w.word}</span>
                      <span class="text-muted" style="font-size: 13px;">${w.ipa || w.pinyin || w.romaji || w.romaja}</span>
                    </div>
                    <div style="font-size: 14px; margin-top: 4px; font-weight: 600;">${w.vi}</div>
                    <div class="text-muted" style="font-size: 12.5px; margin-top: 4px;">Ví dụ: <em>"${w.example}"</em> — ${w.exVi}</div>
                  </div>

                  <button class="btn-icon btn-speak-word" data-word="${w.word}" style="background: var(--surface);">
                    🔊
                  </button>
                </div>
              `).join('')}
            </div>

            <button id="btnNextLessonStep" class="btn-primary mt-6" style="width: 100%;">
              Tiếp tục · Mẫu câu & Ngữ pháp ➔
            </button>
          </div>
        `;

        document.querySelectorAll('.btn-speak-word').forEach(btn => {
          btn.onclick = () => {
            const word = btn.getAttribute('data-word');
            Speech.speak(word, lang);
          };
        });

        document.getElementById('btnNextLessonStep').onclick = () => {
          currentStep = 1;
          updateLesson();
        };
      } else if (currentStep === 1) {
        // Step 2: Grammar / Pattern
        const grammarItems = GRAMMAR_LIBRARY[lang] || GRAMMAR_LIBRARY.en;
        const g = grammarItems[0];

        container.innerHTML = `
          <div style="max-width: 620px; margin: 20px auto;" class="card-soft">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <span class="pill pill-teal">Phần 2/3 · Ngữ pháp đơn giản hóa</span>
              <span class="pill">${g.level}</span>
            </div>

            <h2 style="font-size: 20px; font-weight: 800; margin-bottom: 8px;">${g.title}</h2>
            <p class="text-muted" style="font-size: 14px; margin-bottom: 16px;">${g.desc}</p>

            <div style="padding: 16px; background: var(--teal-light); border: 1.5px solid var(--teal-border); border-radius: var(--radius-md); margin-bottom: 16px;">
              <div style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--teal);">Công thức ghi nhớ:</div>
              <div style="font-size: 15px; font-weight: 800; color: var(--teal); margin-top: 4px;">${g.formula}</div>
            </div>

            <p style="font-size: 14px; line-height: 1.6; margin-bottom: 16px; color: var(--text-main);">
              ${g.explanation}
            </p>

            <div style="background: var(--bg-subtle); padding: 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
              <div style="font-weight: 700; font-size: 13px; margin-bottom: 8px;">Mẫu câu giao tiếp:</div>
              ${g.examples.map(ex => `
                <div style="margin-bottom: 8px;">
                  <div style="font-weight: 700; font-size: 14px; color: var(--primary);">${ex.en || ex.zh || ex.ja || ex.ko}</div>
                  <div class="text-muted" style="font-size: 12.5px;">${ex.vi}</div>
                </div>
              `).join('')}
            </div>

            <button id="btnGoToFeynman" class="btn-primary" style="width: 100%;">
              Dạy lại cho Bắp (Phương pháp Feynman) 🌽 ➔
            </button>
          </div>
        `;

        document.getElementById('btnGoToFeynman').onclick = () => {
          currentStep = 2;
          updateLesson();
        };
      } else if (currentStep === 2) {
        // Step 3: Feynman Technique ("Dạy lại cho Bắp")
        container.innerHTML = `
          <div style="max-width: 620px; margin: 20px auto;" class="card-soft">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <span class="pill pill-primary">Phần 3/3 · Dạy lại cho Bắp</span>
              <span class="text-muted" style="font-size: 13px;">Phương pháp Feynman</span>
            </div>

            <div style="display: flex; gap: 14px; align-items: flex-start; padding: 16px; background: var(--bg-subtle); border-radius: var(--radius-md); margin-bottom: 16px;">
              <span style="font-size: 36px;">🌽</span>
              <div>
                <h4 style="font-weight: 800; font-size: 15px; color: var(--primary);">Bắp (Học sinh mới):</h4>
                <p style="font-size: 14px; line-height: 1.5; margin-top: 4px;">
                  "${feynmanData.mascotQuestion}"
                </p>
              </div>
            </div>

            <p class="text-muted" style="font-size: 13px; margin-bottom: 10px;">
              💡 <em>Hãy giải thích cho Bắp bằng lời bình dân, dễ hiểu nhất như đang nói chuyện với bạn bè:</em>
            </p>

            <textarea id="feynmanAnswer" class="chat-input" style="width: 100%; height: 110px; border-radius: var(--radius-md); resize: none; margin-bottom: 14px;" placeholder="Ví dụ: Căn cứ vào cách phát âm chứ không phải chữ cái viết nha Bắp..."></textarea>

            <div id="feynmanFeedback" style="display: none; padding: 14px; border-radius: var(--radius-md); margin-bottom: 16px; font-size: 14px;"></div>

            <button id="btnSubmitFeynman" class="btn-primary" style="width: 100%;">
              Gửi lời giải thích cho Bắp 🚀
            </button>
          </div>
        `;

        document.getElementById('btnSubmitFeynman').onclick = () => {
          const ans = document.getElementById('feynmanAnswer').value.trim();
          if (!ans) {
            alert('Bạn hãy nhập vài câu giải thích cho Bắp nhé!');
            return;
          }

          const fb = document.getElementById('feynmanFeedback');
          fb.style.display = 'block';

          // Validate keywords
          const hasKeyword = feynmanData.keywords.some(k => ans.toLowerCase().includes(k.toLowerCase()));
          if (hasKeyword || ans.length > 20) {
            fb.style.background = 'var(--teal-light)';
            fb.style.border = '1px solid var(--teal-border)';
            fb.style.color = 'var(--teal)';
            fb.innerHTML = `<strong>🌽 Bắp reo lên:</strong> "${feynmanData.praise}"`;

            document.getElementById('btnSubmitFeynman').textContent = 'Hoàn thành bài học 🎉';
            document.getElementById('btnSubmitFeynman').onclick = () => {
              currentStep = 3;
              updateLesson();
            };
          } else {
            fb.style.background = 'var(--warning-light)';
            fb.style.border = '1px solid var(--warning)';
            fb.style.color = 'var(--text-main)';
            fb.innerHTML = `<strong>🌽 Bắp gãi đầu:</strong> "${feynmanData.encourage}"`;
          }
        };
      } else if (currentStep === 3) {
        // Step 4: Completion & Flashcard addition
        Storage.markLessonDone(lang, lessonId, 100);

        container.innerHTML = `
          <div style="max-width: 580px; margin: 30px auto; text-align: center;" class="card-soft">
            <span style="font-size: 54px;">🥖✨</span>
            <h2 style="font-size: 24px; font-weight: 800; margin-top: 10px;">Tuyệt vời! Bạn đã hoàn thành bài học!</h2>
            <p class="text-muted" style="font-size: 14px; margin-top: 4px;">
              Bạn đã nạp thành công 3 từ vựng và giải thích cực kỳ xuất sắc cho Bắp.
            </p>

            <div style="margin: 24px 0; padding: 18px; background: var(--bg-subtle); border-radius: var(--radius-md); text-align: left;">
              <div style="font-weight: 700; font-size: 13.5px; margin-bottom: 8px;">Đã tự động thêm vào Sổ ôn tập ngắt quãng:</div>
              <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                ${sampleWords.map(w => `
                  <span class="pill pill-primary" style="font-size: 13px;">${w.word} — ${w.vi}</span>
                `).join('')}
              </div>
            </div>

            <div style="display: flex; gap: 12px;">
              <button class="btn-primary" id="btnFinishLesson" style="flex: 1;">
                Về Bảng điều khiển ➔
              </button>
              <button class="btn-secondary" id="btnGoFlashcardsNow" style="flex: 1;">
                Ôn ngay flashcard 📇
              </button>
            </div>
          </div>
        `;

        document.getElementById('btnFinishLesson').onclick = () => this.navigate('dashboard');
        document.getElementById('btnGoFlashcardsNow').onclick = () => this.navigate('flashcards');
      }
    };

    updateLesson();
  },

  // 7. Sổ ôn tập ngắt quãng (Spaced Repetition Flashcards)
  renderFlashcards(container) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const cards = Storage.getFlashcards(lang);
    let cardIdx = 0;
    let isFlipped = false;

    if (cards.length === 0) {
      container.innerHTML = `
        <div class="card-soft" style="max-width: 500px; margin: 40px auto; text-align: center;">
          <span style="font-size: 44px;">📇</span>
          <h3 style="font-size: 19px; font-weight: 700; margin-top: 10px;">Sổ ôn tập đang trống</h3>
          <p class="text-muted" style="font-size: 14px; margin-top: 6px;">
            Hãy hoàn thành bài học đầu tiên hoặc tự thêm từ vựng bạn vừa học trên lớp vào đây nhé!
          </p>
          <button class="btn-primary mt-4" id="btnAddCardEmpty">
            ➕ Thêm từ mới từ lớp học
          </button>
        </div>
      `;
      document.getElementById('btnAddCardEmpty').onclick = () => this.openAddCardModal();
      return;
    }

    const renderCardUI = () => {
      const card = cards[cardIdx];
      isFlipped = false;

      container.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 20px; max-width: 520px; margin: 0 auto;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h1 style="font-size: 22px; font-weight: 800;">Sổ ôn tập ngắt quãng</h1>
              <p class="text-muted" style="font-size: 13px;">Thẻ khó sẽ tự quay lại sớm hơn</p>
            </div>

            <div style="display: flex; gap: 8px;">
              <button class="pill pill-primary" id="btnOpenAddModal">
                ➕ Thêm từ mới
              </button>
              <span class="pill">
                ${cardIdx + 1} / ${cards.length}
              </span>
            </div>
          </div>

          <!-- 3D Flip Card Container -->
          <div class="flip-container">
            <div class="flip-card" id="activeFlipCard">
              <!-- Front Face -->
              <div class="flip-face">
                <span class="pill pill-primary" style="position: absolute; top: 18px; left: 18px; font-size: 11px;">
                  Hộp ${card.box || 1} · ${card.topic}
                </span>

                <button class="btn-icon" id="btnSpeakFront" style="position: absolute; top: 14px; right: 14px;" title="Nghe phát âm">
                  🔊
                </button>

                <h2 style="font-size: 34px; font-weight: 800; color: var(--primary); letter-spacing: -0.01em;">
                  ${card.word}
                </h2>
                <div class="text-muted" style="font-size: 15px; margin-top: 6px;">
                  ${card.ipa}
                </div>

                <div class="text-muted" style="position: absolute; bottom: 20px; font-size: 11.5px; text-transform: uppercase; letter-spacing: 0.1em;">
                  👆 Chạm để lật xem nghĩa
                </div>
              </div>

              <!-- Back Face -->
              <div class="flip-face flip-face-back">
                <span class="pill pill-teal" style="position: absolute; top: 18px; left: 18px; font-size: 11px;">
                  Nghĩa tiếng Việt
                </span>

                <h3 style="font-size: 24px; font-weight: 800; color: var(--teal);">
                  ${card.vi}
                </h3>

                ${card.example ? `
                  <div style="margin-top: 14px; padding: 12px; background: var(--surface); border-radius: var(--radius-md); border: 1px solid var(--border); font-size: 13.5px; text-align: left; width: 100%;">
                    <div style="font-weight: 700; color: var(--text-main);">"${card.example}"</div>
                    <div class="text-muted" style="font-size: 12px; margin-top: 2px;">${card.exVi}</div>
                  </div>
                ` : ''}

                <div class="text-muted" style="position: absolute; bottom: 18px; font-size: 11.5px;">
                  Nhớ tự đánh giá thật thà nhé!
                </div>
              </div>
            </div>
          </div>

          <!-- Evaluation Buttons -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
            <button class="btn-secondary" id="btnForgot" style="border-color: #E9B4AE; background: #FDF1EF; color: #B5534A; padding: 14px;">
              ❌ Chưa nhớ (Ôn lại sớm)
            </button>
            <button class="btn-primary" id="btnRemembered" style="padding: 14px;">
              ✅ Đã nhớ (Lên hộp ${Math.min(5, (card.box || 1) + 1)})
            </button>
          </div>

          <div style="text-align: center;">
            <button class="btn-ghost" id="btnDeleteCard" style="font-size: 12px; color: var(--text-muted);">
              🗑️ Xóa thẻ này khỏi sổ
            </button>
          </div>
        </div>
      `;

      // Flip card on click
      const flipEl = document.getElementById('activeFlipCard');
      flipEl.onclick = (e) => {
        if (e.target.closest('#btnSpeakFront')) return;
        isFlipped = !isFlipped;
        flipEl.classList.toggle('is-flipped', isFlipped);
      };

      document.getElementById('btnSpeakFront').onclick = (e) => {
        e.stopPropagation();
        Speech.speak(card.word, lang);
      };

      document.getElementById('btnRemembered').onclick = () => {
        Storage.updateCardReview(lang, card.id, true);
        if (cardIdx < cards.length - 1) {
          cardIdx += 1;
          renderCardUI();
        } else {
          alert('Tuyệt vời! Bạn đã hoàn thành lượt ôn tập tất cả các thẻ hôm nay!');
          this.navigate('dashboard');
        }
      };

      document.getElementById('btnForgot').onclick = () => {
        Storage.updateCardReview(lang, card.id, false);
        if (cardIdx < cards.length - 1) {
          cardIdx += 1;
          renderCardUI();
        } else {
          alert('Lượt ôn tập đã xong! Các thẻ chưa nhớ sẽ quay lại sớm để bạn củng cố nhé.');
          this.navigate('dashboard');
        }
      };

      document.getElementById('btnDeleteCard').onclick = () => {
        if (confirm(`Bạn có chắc muốn xóa từ "${card.word}" không?`)) {
          Storage.deleteCard(lang, card.id);
          this.renderFlashcards(container);
        }
      };

      document.getElementById('btnOpenAddModal').onclick = () => this.openAddCardModal();
    };

    renderCardUI();
  },

  // 8. Bạn AI luyện nói & Giao tiếp tự tin (Voice & Chat Buddy)
  renderSpeaking(container) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const langInfo = LANGUAGES[lang] || LANGUAGES.en;
    let activeTopic = AI_TOPICS.find(t => t.id === this.state.activeTopicId) || AI_TOPICS[0];

    // Initialize initial message if empty
    if (!this.state.feynmanChat || this.state.feynmanChat.length === 0) {
      this.state.feynmanChat = [
        {
          sender: 'ai',
          text: activeTopic.starters[lang] || activeTopic.starters.en,
          vi: 'Lời chào mở đầu từ bạn AI.'
        }
      ];
    }

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
          <div>
            <h1 style="font-size: 24px; font-weight: 800;">Bạn AI luyện nói không phán xét</h1>
            <p class="text-muted" style="font-size: 13.5px;">Tự tin nói bằng giọng của bạn (${langInfo.label}). Không sợ sai, không ai cười bạn cả!</p>
          </div>

          <div style="display: flex; gap: 8px;">
            <button class="pill pill-primary" id="btnToggleSpeechSound">
              🔊 Đọc tự động: Bật
            </button>
          </div>
        </div>

        <!-- Topic Pill Selector -->
        <div style="display: flex; gap: 8px; overflow-x: auto; padding-bottom: 6px;">
          ${AI_TOPICS.map(topic => `
            <button class="pill ${topic.id === activeTopic.id ? 'pill-primary' : ''} topic-pill-btn" data-topic="${topic.id}" style="padding: 8px 16px; font-size: 13px; white-space: nowrap;">
              ${topic.emoji} ${topic.title}
            </button>
          `).join('')}
        </div>

        <!-- Chat Container -->
        <div class="chat-window">
          <!-- Messages -->
          <div class="chat-messages" id="chatMessagesBox">
            ${this.state.feynmanChat.map(msg => `
              <div class="chat-bubble ${msg.sender === 'user' ? 'chat-bubble-user' : 'chat-bubble-ai'}">
                <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
                  <span>${msg.text}</span>
                  <button class="btn-icon btn-speak-chat-msg" data-text="${msg.text}" style="width: 28px; height: 28px; font-size: 13px; background: rgba(0,0,0,0.06);">
                    🔊
                  </button>
                </div>

                ${msg.accuracy !== undefined ? `
                  <div style="margin-top: 8px; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.3); font-size: 12px;">
                    <div>Độ chuẩn xác phát âm: <strong>${msg.accuracy}%</strong></div>
                    <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px;">
                      ${msg.evaluatedWords.map(ew => `
                        <span style="padding: 2px 6px; border-radius: 4px; font-size: 11px; background: ${ew.matched ? '#2E7D32' : '#C62828'}; color: white;">
                          ${ew.word}
                        </span>
                      `).join('')}
                    </div>
                  </div>
                ` : ''}
              </div>
            `).join('')}
          </div>

          <!-- Suggested Quick Replies -->
          <div style="padding: 8px 18px; background: var(--bg-subtle); border-top: 1px solid var(--border); display: flex; gap: 8px; overflow-x: auto;">
            <span class="text-muted" style="font-size: 12px; align-self: center; white-space: nowrap;">Gợi ý câu:</span>
            ${(activeTopic.hints || []).map(h => `
              <button class="pill quick-reply-btn" data-reply="${h.text}" style="white-space: nowrap; font-size: 12px; background: var(--surface);">
                💬 "${h.text}"
              </button>
            `).join('')}
          </div>

          <!-- Chat Input Bar with Microphone -->
          <div class="chat-input-bar">
            <button class="btn-icon mic-btn" id="btnMicRecord" title="Nói bằng giọng nói qua micro" style="background: var(--bg-subtle);">
              🎙️
            </button>

            <input type="text" id="chatTextInput" class="chat-input" placeholder="Nhập câu trả lời hoặc bấm micro để nói..." />

            <button class="btn-primary" id="btnSendChat" style="padding: 10px 20px;">
              Gửi
            </button>
          </div>
        </div>
      </div>
    `;

    // Speak AI messages
    document.querySelectorAll('.btn-speak-chat-msg').forEach(btn => {
      btn.onclick = () => {
        const text = btn.getAttribute('data-text');
        Speech.speak(text, lang);
      };
    });

    // Topic switcher
    document.querySelectorAll('.topic-pill-btn').forEach(btn => {
      btn.onclick = () => {
        const tId = btn.getAttribute('data-topic');
        this.state.activeTopicId = tId;
        this.state.feynmanChat = [];
        this.renderSpeaking(container);
      };
    });

    // Quick reply click
    document.querySelectorAll('.quick-reply-btn').forEach(btn => {
      btn.onclick = () => {
        const text = btn.getAttribute('data-reply');
        document.getElementById('chatTextInput').value = text;
      };
    });

    // Send Message Handler
    const handleSend = (text, isVoice = false, evalResult = null) => {
      if (!text || !text.trim()) return;

      const userMsg = {
        sender: 'user',
        text: text.trim(),
        accuracy: evalResult ? evalResult.score : undefined,
        evaluatedWords: evalResult ? evalResult.words : undefined
      };

      this.state.feynmanChat.push(userMsg);
      document.getElementById('chatTextInput').value = '';

      // Generate AI response
      setTimeout(() => {
        const aiReplies = [
          "That's awesome! You explained that so clearly and naturally.",
          "I totally agree with you. What do you think about doing that together this weekend?",
          "Great job! Your pronunciation is getting much better every day.",
          "Sounds like a plan! Let's grab some coffee and chat more about it soon."
        ];
        const aiText = aiReplies[Math.floor(Math.random() * aiReplies.length)];

        this.state.feynmanChat.push({
          sender: 'ai',
          text: aiText
        });

        Speech.speak(aiText, lang);
        this.renderSpeaking(container);
      }, 700);

      this.renderSpeaking(container);
    };

    document.getElementById('btnSendChat').onclick = () => {
      const val = document.getElementById('chatTextInput').value;
      handleSend(val);
    };

    document.getElementById('chatTextInput').onkeydown = (e) => {
      if (e.key === 'Enter') {
        const val = document.getElementById('chatTextInput').value;
        handleSend(val);
      }
    };

    // Microphone Speech Recognition
    const micBtn = document.getElementById('btnMicRecord');
    let isRecording = false;

    micBtn.onclick = () => {
      if (!isRecording) {
        Speech.startListening(
          lang,
          (transcript) => {
            // Recognized!
            isRecording = false;
            micBtn.classList.remove('recording');

            // Find target reference from hints
            const targetHint = (activeTopic.hints && activeTopic.hints[0]) ? activeTopic.hints[0].text : transcript;
            const evalResult = Speech.calculateAccuracy(targetHint, transcript);

            handleSend(transcript, true, evalResult);
          },
          (err) => {
            alert(err);
            isRecording = false;
            micBtn.classList.remove('recording');
          },
          () => {
            isRecording = true;
            micBtn.classList.add('recording');
          },
          () => {
            isRecording = false;
            micBtn.classList.remove('recording');
          }
        );
      } else {
        Speech.stopListening();
        isRecording = false;
        micBtn.classList.remove('recording');
      }
    };
  },

  // 9. Thư viện Ngữ pháp & Bảng phát âm IPA (Library & Phonetics)
  renderLibrary(container) {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const langInfo = LANGUAGES[lang] || LANGUAGES.en;
    const grammarList = GRAMMAR_LIBRARY[lang] || GRAMMAR_LIBRARY.en;
    const phoneticsList = PHONETICS_DATA[lang] || PHONETICS_DATA.en;

    let activeTab = 'grammar'; // 'grammar' or 'phonetics'

    const renderTabs = () => {
      container.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 24px;">
          <div>
            <h1 style="font-size: 24px; font-weight: 800;">Thư viện ngữ pháp & Bảng phát âm</h1>
            <p class="text-muted" style="font-size: 14px;">Tra cứu nhanh mọi cấu trúc câu và âm vị chuẩn của ${langInfo.label}.</p>
          </div>

          <!-- Tab Selector -->
          <div style="display: flex; gap: 10px; border-bottom: 1px solid var(--border); padding-bottom: 8px;">
            <button class="pill ${activeTab === 'grammar' ? 'pill-primary' : ''}" id="tabGrammarBtn" style="padding: 8px 18px; font-size: 14px;">
              🧩 Ngữ pháp trọng điểm (${grammarList.length})
            </button>
            <button class="pill ${activeTab === 'phonetics' ? 'pill-primary' : ''}" id="tabPhoneticsBtn" style="padding: 8px 18px; font-size: 14px;">
              🗣️ Bảng phát âm chuẩn
            </button>
          </div>

          ${activeTab === 'grammar' ? `
            <div style="display: flex; flex-direction: column; gap: 16px;">
              ${grammarList.map(g => `
                <div class="card-soft">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <h3 style="font-size: 18px; font-weight: 800; color: var(--primary);">${g.title}</h3>
                    <span class="pill pill-teal">${g.level}</span>
                  </div>

                  <p class="text-muted" style="font-size: 13.5px; margin-bottom: 12px;">${g.desc}</p>

                  <div style="padding: 12px 16px; background: var(--bg-subtle); border-radius: var(--radius-md); font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 12px;">
                    📐 Công thức: ${g.formula}
                  </div>

                  <p style="font-size: 14px; line-height: 1.6; margin-bottom: 14px;">
                    ${g.explanation}
                  </p>

                  <div style="background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 14px; margin-bottom: 10px;">
                    <div style="font-size: 12.5px; font-weight: 700; text-transform: uppercase; color: var(--text-muted); margin-bottom: 6px;">Ví dụ tiêu biểu:</div>
                    ${g.examples.map(ex => `
                      <div style="margin-bottom: 6px;">
                        <span style="font-weight: 700; color: var(--primary);">${ex.en || ex.zh || ex.ja || ex.ko}</span>
                        <span class="text-muted" style="font-size: 13px;"> — ${ex.vi}</span>
                      </div>
                    `).join('')}
                  </div>

                  <div style="font-size: 12.5px; color: var(--teal); font-weight: 600;">
                    💡 Mẹo hay: ${g.tip}
                  </div>
                </div>
              `).join('')}
            </div>
          ` : `
            <div style="display: flex; flex-direction: column; gap: 20px;">
              ${phoneticsList.map(cat => `
                <div class="card-soft">
                  <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 14px; color: var(--primary);">${cat.category}</h3>
                  <div class="grid-3">
                    ${cat.sounds.map(s => `
                      <div style="padding: 12px; background: var(--bg-subtle); border-radius: var(--radius-md); display: flex; justify-content: space-between; align-items: center;">
                        <div>
                          <div style="font-size: 18px; font-weight: 800; color: var(--primary);">${s.symbol}</div>
                          <div style="font-size: 13px; font-weight: 600;">"${s.word}"</div>
                          <div class="text-muted" style="font-size: 11px;">${s.vi}</div>
                        </div>

                        <button class="btn-icon btn-speak-phonetic" data-speak="${s.speak}" style="background: var(--surface);">
                          🔊
                        </button>
                      </div>
                    `).join('')}
                  </div>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      `;

      document.getElementById('tabGrammarBtn').onclick = () => {
        activeTab = 'grammar';
        renderTabs();
      };

      document.getElementById('tabPhoneticsBtn').onclick = () => {
        activeTab = 'phonetics';
        renderTabs();
      };

      document.querySelectorAll('.btn-speak-phonetic').forEach(btn => {
        btn.onclick = () => {
          const speakText = btn.getAttribute('data-speak');
          Speech.speak(speakText, lang);
        };
      });
    };

    renderTabs();
  },

  // 10. Đồng hồ Pomodoro 25/5 & Quy tắc 70/30 (Pomodoro Focus)
  renderPomodoro(container) {
    const stats = Storage.getPomodoro();
    const p = this.state.pomodoro;

    const formatTime = (secs) => {
      const m = Math.floor(secs / 60);
      const s = secs % 60;
      return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    };

    const updateTimerDisplay = () => {
      const displayEl = document.getElementById('pomoTimeText');
      if (displayEl) {
        displayEl.textContent = formatTime(p.timeLeft);
      }
      const ringEl = document.getElementById('pomoRingProgress');
      if (ringEl) {
        const circumference = 691;
        const progress = 1 - (p.timeLeft / p.initialTime);
        ringEl.style.strokeDashoffset = circumference * progress;
      }
    };

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 24px; max-width: 600px; margin: 0 auto; text-align: center;">
        <div>
          <span class="pill pill-primary">Phương pháp học tập trung</span>
          <h1 style="font-size: 26px; font-weight: 800; margin-top: 8px;">Đồng hồ Pomodoro 25/5</h1>
          <p class="text-muted" style="font-size: 14px;">25 phút học sâu, 5 phút nghỉ ngơi — Tránh kiệt sức và quá tải.</p>
        </div>

        <!-- 70/30 Rule Explanation Banner -->
        <div style="padding: 16px; background: var(--bg-subtle); border-radius: var(--radius-lg); text-align: left; display: flex; gap: 14px; align-items: center;">
          <span style="font-size: 32px;">📊</span>
          <div>
            <div style="font-weight: 700; font-size: 14px;">Quy tắc 70/30 (Ý tưởng nhóm 7)</div>
            <div class="text-muted" style="font-size: 12.5px; line-height: 1.4;">
              Dành <strong>70% thời gian</strong> ôn lại thẻ Spaced Repetition và <strong>30% thời gian</strong> giải bài tập nhanh để kiến thức đi vào trí nhớ dài hạn.
            </div>
          </div>
        </div>

        <!-- Circular Timer Ring -->
        <div class="pomodoro-ring">
          <svg width="240" height="240">
            <circle class="bg-ring" cx="120" cy="120" r="110" />
            <circle class="progress-ring" id="pomoRingProgress" cx="120" cy="120" r="110" />
          </svg>
          <div class="pomodoro-time-display">
            <div id="pomoTimeText" style="font-size: 44px; font-weight: 800; letter-spacing: -0.02em;">
              ${formatTime(p.timeLeft)}
            </div>
            <span class="pill pill-teal" id="pomoPhaseText" style="font-size: 12px; margin-top: 6px;">
              ${p.isBreak ? '☕ Giờ nghỉ giải lao (5p)' : '🎯 Tập trung học (25p)'}
            </span>
          </div>
        </div>

        <!-- Timer Controls -->
        <div style="display: flex; justify-content: center; gap: 14px;">
          <button class="btn-primary" id="btnTogglePomo" style="padding: 14px 32px; font-size: 16px;">
            ${p.isRunning ? '⏸️ Tạm dừng' : '▶️ Bắt đầu học'}
          </button>
          <button class="btn-secondary" id="btnResetPomo">
            🔄 Đặt lại
          </button>
        </div>

        <!-- Stats -->
        <div class="grid-2 mt-4" style="text-align: left;">
          <div class="card-soft">
            <div class="text-muted" style="font-size: 12px; text-transform: uppercase; font-weight: 700;">Phiên hoàn thành</div>
            <div style="font-size: 26px; font-weight: 800; color: var(--primary); margin-top: 4px;">
              ${stats.completedSessions} phiên
            </div>
          </div>

          <div class="card-soft">
            <div class="text-muted" style="font-size: 12px; text-transform: uppercase; font-weight: 700;">Tổng thời gian tập trung</div>
            <div style="font-size: 26px; font-weight: 800; color: var(--teal); margin-top: 4px;">
              ${stats.totalMinutes} phút
            </div>
          </div>
        </div>
      </div>
    `;

    updateTimerDisplay();

    const startTimer = () => {
      if (p.intervalId) clearInterval(p.intervalId);
      p.isRunning = true;
      p.intervalId = setInterval(() => {
        if (p.timeLeft > 0) {
          p.timeLeft -= 1;
          updateTimerDisplay();
        } else {
          // Completed session
          clearInterval(p.intervalId);
          p.isRunning = false;

          if (!p.isBreak) {
            Storage.incrementPomodoro(25);
            alert('🎉 Chúc mừng bạn đã hoàn thành 25 phút học tập trung! Hãy nghỉ giải lao 5 phút nhé!');
            p.isBreak = true;
            p.timeLeft = 5 * 60;
            p.initialTime = 5 * 60;
          } else {
            alert('Hết giờ nghỉ 5 phút rồi, sẵn sàng vào phiên tập trung mới nào!');
            p.isBreak = false;
            p.timeLeft = 25 * 60;
            p.initialTime = 25 * 60;
          }

          this.renderPomodoro(container);
        }
      }, 1000);
    };

    const pauseTimer = () => {
      p.isRunning = false;
      if (p.intervalId) clearInterval(p.intervalId);
    };

    document.getElementById('btnTogglePomo').onclick = () => {
      if (p.isRunning) {
        pauseTimer();
        document.getElementById('btnTogglePomo').textContent = '▶️ Tiếp tục';
      } else {
        startTimer();
        document.getElementById('btnTogglePomo').textContent = '⏸️ Tạm dừng';
      }
    };

    document.getElementById('btnResetPomo').onclick = () => {
      pauseTimer();
      p.timeLeft = 25 * 60;
      p.initialTime = 25 * 60;
      p.isBreak = false;
      this.renderPomodoro(container);
    };
  },

  // 11. Modal Kiểm tra đột xuất (Pop Quiz)
  openPopQuizModal() {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';
    const qList = PLACEMENT_QUESTIONS[lang] || PLACEMENT_QUESTIONS.en;

    // Pick 3 random questions
    const shuffled = [...qList].sort(() => 0.5 - Math.random()).slice(0, 3);
    let qIdx = 0;
    let correctCount = 0;

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    document.body.appendChild(modal);

    const renderQuiz = () => {
      if (qIdx < shuffled.length) {
        const q = shuffled[qIdx];
        modal.innerHTML = `
          <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span class="pill pill-primary">Kiểm tra đột xuất ⚡ (Câu ${qIdx + 1}/3)</span>
              <button class="btn-icon" id="btnCloseQuiz" style="width: 32px; height: 32px;">✕</button>
            </div>

            <h3 style="font-size: 17px; font-weight: 700; margin-bottom: 16px;">${q.prompt}</h3>

            <div style="display: flex; flex-direction: column; gap: 10px;">
              ${q.options.map((opt, oIdx) => `
                <button type="button" class="btn-secondary pop-opt-btn" data-idx="${oIdx}" style="justify-content: flex-start; text-align: left; padding: 12px 16px; font-size: 14.5px;">
                  ${['A', 'B', 'C', 'D'][oIdx]}. ${opt}
                </button>
              `).join('')}
            </div>
          </div>
        `;

        document.getElementById('btnCloseQuiz').onclick = () => modal.remove();

        modal.querySelectorAll('.pop-opt-btn').forEach(btn => {
          btn.onclick = () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            if (idx === q.answer) correctCount += 1;
            qIdx += 1;
            renderQuiz();
          };
        });
      } else {
        modal.innerHTML = `
          <div class="modal-content" style="text-align: center;">
            <span style="font-size: 42px;">🌟</span>
            <h3 style="font-size: 20px; font-weight: 800; margin-top: 8px;">Hoàn thành kiểm tra đột xuất!</h3>
            <p style="font-size: 15px; margin-top: 4px;">Bạn trả lời đúng: <strong>${correctCount}/3 câu</strong></p>
            <p class="text-muted" style="font-size: 13px; margin-top: 8px;">
              Bài test nhỏ giúp kích hoạt trí nhớ chủ động (active recall), hỗ trợ sinh viên nhớ kiến thức sâu gấp 3 lần!
            </p>
            <button class="btn-primary mt-4" id="btnCloseQuizSuccess" style="width: 100%;">
              Đóng và tiếp tục học
            </button>
          </div>
        `;
        document.getElementById('btnCloseQuizSuccess').onclick = () => modal.remove();
      }
    };

    renderQuiz();
  },

  // 12. Modal Thêm thẻ ghi nhớ tùy chỉnh (Quick Add Custom Word)
  openAddCardModal() {
    const profile = Storage.getProfile();
    const lang = profile.language || 'en';

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    document.body.appendChild(modal);

    modal.innerHTML = `
      <div class="modal-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <h3 style="font-size: 18px; font-weight: 800;">➕ Thêm từ vựng mới</h3>
          <button class="btn-icon" id="btnCloseAddModal" style="width: 32px; height: 32px;">✕</button>
        </div>

        <form id="addCardForm" style="display: flex; flex-direction: column; gap: 12px;">
          <div>
            <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Từ hoặc cụm từ</label>
            <input type="text" id="cardWordInput" class="chat-input" style="width: 100%; margin-top: 4px;" placeholder="Ví dụ: semester" required />
          </div>

          <div>
            <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Phiên âm / Cách đọc (không bắt buộc)</label>
            <input type="text" id="cardIpaInput" class="chat-input" style="width: 100%; margin-top: 4px;" placeholder="Ví dụ: /sɪˈmestər/" />
          </div>

          <div>
            <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Nghĩa tiếng Việt</label>
            <input type="text" id="cardViInput" class="chat-input" style="width: 100%; margin-top: 4px;" placeholder="Ví dụ: học kỳ" required />
          </div>

          <div>
            <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Câu ví dụ (không bắt buộc)</label>
            <input type="text" id="cardExInput" class="chat-input" style="width: 100%; margin-top: 4px;" placeholder="Ví dụ: This semester is very busy." />
          </div>

          <button type="submit" class="btn-primary mt-2" style="width: 100%;">
            Lưu vào Sổ ôn tập ngắt quãng 💾
          </button>
        </form>
      </div>
    `;

    document.getElementById('btnCloseAddModal').onclick = () => modal.remove();

    document.getElementById('addCardForm').onsubmit = (e) => {
      e.preventDefault();
      const word = document.getElementById('cardWordInput').value;
      const ipa = document.getElementById('cardIpaInput').value;
      const vi = document.getElementById('cardViInput').value;
      const ex = document.getElementById('cardExInput').value;

      Storage.addCustomCard(lang, { word, ipa, vi, example: ex });
      modal.remove();
      this.navigate('flashcards');
    };
  },

  // 13. Modal Đổi Ngôn ngữ Học tập (Change Language)
  openLanguageModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    document.body.appendChild(modal);

    modal.innerHTML = `
      <div class="modal-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <h3 style="font-size: 18px; font-weight: 800;">Chọn ngôn ngữ học tập</h3>
          <button class="btn-icon" id="btnCloseLangModal" style="width: 32px; height: 32px;">✕</button>
        </div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
          ${Object.values(LANGUAGES).map(lang => `
            <button class="btn-secondary lang-select-opt" data-lang="${lang.code}" style="padding: 14px; justify-content: flex-start; text-align: left; display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 26px;">${lang.flag}</span>
              <div style="flex: 1;">
                <div style="font-weight: 700; font-size: 15px;">${lang.label}</div>
                <div class="text-muted" style="font-size: 12px;">${lang.desc}</div>
              </div>
            </button>
          `).join('')}
        </div>
      </div>
    `;

    document.getElementById('btnCloseLangModal').onclick = () => modal.remove();

    modal.querySelectorAll('.lang-select-opt').forEach(btn => {
      btn.onclick = () => {
        const langCode = btn.getAttribute('data-lang');
        Storage.saveProfile({ language: langCode });
        modal.remove();
        this.init();
      };
    });
  },

  // 14. Màn hình Cài đặt (Settings)
  renderSettings(container) {
    const profile = Storage.getProfile();

    container.innerHTML = `
      <div style="max-width: 600px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800;">Cài đặt ứng dụng</h1>
          <p class="text-muted" style="font-size: 14px;">Tùy chỉnh trải nghiệm học tập của bạn.</p>
        </div>

        <div class="card-soft">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px;">Thông tin cá nhân</h3>
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div>
              <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Tên hiển thị</label>
              <input type="text" id="settingNameInput" class="chat-input" style="width: 100%; margin-top: 4px;" value="${profile.name || ''}" />
            </div>

            <div>
              <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Thời gian học mục tiêu mỗi ngày</label>
              <select id="settingDailyMins" class="chat-input" style="width: 100%; margin-top: 4px;">
                <option value="5" ${profile.dailyMinutes === 5 ? 'selected' : ''}>5 phút / ngày (Nhẹ nhàng)</option>
                <option value="10" ${profile.dailyMinutes === 10 ? 'selected' : ''}>10 phút / ngày (Tiêu chuẩn)</option>
                <option value="15" ${profile.dailyMinutes === 15 ? 'selected' : ''}>15 phút / ngày (Bứt phá)</option>
              </select>
            </div>

            <button class="btn-primary mt-2" id="btnSaveProfileSettings">
              Lưu thay đổi 💾
            </button>
          </div>
        </div>

        <div class="card-soft">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px;">Âm thanh & Giọng đọc</h3>
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div>
              <label style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Tốc độ đọc phát âm</label>
              <input type="range" id="settingVoiceRate" min="0.7" max="1.2" step="0.05" value="${profile.voiceRate || 0.95}" style="width: 100%; margin-top: 6px;" />
              <div class="text-muted" style="font-size: 12px; display: flex; justify-content: space-between;">
                <span>0.7x (Chậm rõ)</span>
                <span>1.0x (Chuẩn)</span>
                <span>1.2x (Nhanh)</span>
              </div>
            </div>

            <button class="btn-secondary" id="btnTestVoice" style="align-self: flex-start; margin-top: 6px;">
              🔊 Thử giọng đọc mẫu
            </button>
          </div>
        </div>

        <div class="card-soft" style="border-color: var(--danger-light);">
          <h3 style="font-size: 16px; font-weight: 700; color: var(--danger); margin-bottom: 8px;">Dữ liệu & Đặt lại</h3>
          <p class="text-muted" style="font-size: 13px; margin-bottom: 12px;">
            Toàn bộ tiến độ học, sổ thẻ nhớ và chuỗi streak được lưu an toàn trên máy của bạn.
          </p>
          <button class="btn-secondary" id="btnResetAllData" style="color: var(--danger); border-color: var(--danger);">
            ⚠️ Xóa toàn bộ dữ liệu & Làm lại từ đầu
          </button>
        </div>
      </div>
    `;

    document.getElementById('btnSaveProfileSettings').onclick = () => {
      const name = document.getElementById('settingNameInput').value.trim();
      const dailyMins = parseInt(document.getElementById('settingDailyMins').value);
      const voiceRate = parseFloat(document.getElementById('settingVoiceRate').value);

      Storage.saveProfile({ name, dailyMinutes: dailyMins, voiceRate });
      alert('Đã cập nhật cài đặt thành công!');
    };

    document.getElementById('btnTestVoice').onclick = () => {
      Speech.speak("Hello! Welcome to Banh Mi Language Buddy. Enjoy learning with no pressure!", profile.language || 'en');
    };

    document.getElementById('btnResetAllData').onclick = () => {
      if (confirm('Bạn có chắc chắn muốn xóa toàn bộ dữ liệu và bắt đầu lại từ đầu không?')) {
        Storage.resetAll();
        location.reload();
      }
    };
  },

  // 15. Thông tin Nhóm 7 & Đề tài Design Thinking (Credits)
  renderCredits(container) {
    const cred = PROJECT_CREDITS;

    container.innerHTML = `
      <div style="max-width: 650px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px;">
        <div style="text-align: center;">
          <img src="assets/logo.svg" alt="Logo" style="width: 72px; height: 72px; margin: 0 auto 12px;" />
          <span class="pill pill-primary">${cred.university}</span>
          <h1 style="font-size: 24px; font-weight: 800; margin-top: 8px;">BÁNH MÌ NGÔN NGỮ</h1>
          <p class="text-muted" style="font-size: 14px;">Học phần: ${cred.course} — ${cred.team}</p>
        </div>

        <!-- Problem & Solution Overview -->
        <div class="card-soft">
          <h3 style="font-size: 17px; font-weight: 800; color: var(--primary); margin-bottom: 8px;">1. Persona: ${cred.persona.name} (${cred.persona.age} tuổi)</h3>
          <p class="text-muted" style="font-size: 13.5px; margin-bottom: 12px;">${cred.persona.role}</p>

          <div style="background: var(--bg-subtle); padding: 14px; border-radius: var(--radius-md); font-size: 13.5px; line-height: 1.6; margin-bottom: 12px;">
            <strong>Khó khăn & Nỗi đau (Pains):</strong><br/>
            ${cred.persona.pains}
          </div>

          <div style="background: var(--teal-light); padding: 14px; border-radius: var(--radius-md); font-size: 13.5px; line-height: 1.6; color: var(--teal);">
            <strong>Mục tiêu sản phẩm:</strong><br/>
            ${cred.persona.goals}
          </div>
        </div>

        <!-- 4 Core Pillars of Ideate -->
        <div class="card-soft">
          <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 12px;">2. Bốn trụ cột phương pháp (Ideate)</h3>
          <div style="display: flex; flex-direction: column; gap: 10px; font-size: 13.5px;">
            <div><strong>1. Lặp lại ngắt quãng (Spaced Repetition):</strong> Ôn lại thẻ kiến thức theo mốc thời gian tăng dần (Hộp 1 đến 5).</div>
            <div><strong>2. Phương pháp Feynman:</strong> "Dạy lại cho Bắp" để biến kiến thức phức tạp thành lời nói bình dân của mình.</div>
            <div><strong>3. Áp dụng Pomodoro 25/5:</strong> Học 25 phút, nghỉ 5 phút tránh kiệt sức não bộ.</div>
            <div><strong>4. Nguyên tắc 70/30:</strong> 70% ôn tập củng cố, 30% luyện bài tập phản xạ.</div>
          </div>
        </div>

        <!-- Team Members Table -->
        <div class="card-soft">
          <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 14px;">3. Danh sách thành viên Nhóm 7 (Quyết Chiến)</h3>
          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${cred.members.map(m => `
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: var(--bg-subtle); border-radius: var(--radius-md);">
                <div>
                  <div style="font-weight: 800; font-size: 14.5px;">${m.name}</div>
                  <div class="text-muted" style="font-size: 12px;">MSSV: ${m.id} · ${m.task}</div>
                </div>
                <span class="pill pill-primary" style="font-weight: 700;">${m.role}</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }
};

// Auto start when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
